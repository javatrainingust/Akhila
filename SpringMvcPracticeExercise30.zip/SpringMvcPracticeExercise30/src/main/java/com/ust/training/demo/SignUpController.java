/**
 * SignUpController
 * SignUpController is a controller class it have a  method showForm which return a jsp page.
 * 15-10-2020
 */


package com.ust.training.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
/**
 *SignUpController is a controller class it have a  method showForm which return a jsp page. 
 */
public class SignUpController {
	@RequestMapping("/form")
	/**
	 * showForm method where we create signup object
	 */
	public String showForm(Model theModel) {
		
		// create a student object
		SignUp signup = new SignUp();
		
		signup.setUserName("Akhila");
		signup.setUserId("Ak123");
		signup.setPassword("Anju1234");
		signup.setConfirmPassword("Anju1234");
		
		
		// add student object to the model
		theModel.addAttribute("key", signup);
		
		return "signUp";
	}
	
	@RequestMapping("/processForm")
	/**
	 * processForm method retuens confirmSignUp jsp page
	 */
	public String processForm(@ModelAttribute("user") SignUp signup) {
		
		// log the input data
		System.out.println("signup: " + signup.getUserName()+" "+signup.getUserId()+" "+signup.getPassword()+" "+signup.getConfirmPassword());
		
		return "confirmSignUp";
	}
	
}







