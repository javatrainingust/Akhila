/**
 * SignUp
 * SignUp class is the model class for Signing up by entering details .
 * 15/10/20
 * */

package com.ust.training.demo;
/**
 * SignUp class is the model class which contains following fields.
 */
public class SignUp {
	private String userName;
	private String userId;
	private String password;
	private String confirmPassword;
	/**
	 * getter for Username
	 * */
	public String getUserName() {
		return userName;
	}
	/**
	 * setter for Username
	 * */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * getter for UserId
	 * */
	public String getUserId() {
		return userId;
	}
	/**
	 * setter for UserId
	 * */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * getter for password
	 * */
	public String getPassword() {
		return password;
	}
	/**
	 * setter for password
	 * */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * getter for ConfirmPassword
	 * */
	public String getConfirmPassword() {
		return confirmPassword;
	}
	/**
	 * setter for ConfirmPassword
	 * */
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	

}
