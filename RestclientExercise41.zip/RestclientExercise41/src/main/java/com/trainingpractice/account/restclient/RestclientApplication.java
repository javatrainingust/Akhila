/**
 * RestclientApplication
 * 
 * RestclientApplication  class is a synchronous client that is designed to call REST services
 *
 * 28/10/20
 * 
*/

package com.trainingpractice.account.restclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.trainingpractice.account.restclient.model.SBAccount;
/**
 *RestclientApplication  class is a synchronous client that is designed to call REST services
 */
@SpringBootApplication
public class RestclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestclientApplication.class, args);
		// getAccount();
		// postAccounts();
		// putAccounts();
		// deleteAccounts();
		// getAllAccounts();
	}
/**
 *  getAccount() to get a account based on accountNo
 */
	public static void getAccount() {

		RestTemplate restTemplate = new RestTemplate();
		final String uri = "http://localhost:8080/bankingapplication/accounts/{accNo}";

		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("accNo", 1003);
		SBAccount result = restTemplate.getForObject(uri, SBAccount.class, params);
		System.out.println("The Account Holder Name=" + result.getAccountHolderName());
		System.out.println("The Account balance =" + result.getBalance());

	}
	/**
	 * getAllAccounts() to get all SBAccounts
	 * 
	 *ResponseEntity<SBAccount[]> getForEntity(uri, SBAccount[].class) is to  Executes a GET request and returns a ResponseEntity that contains both the status code and the resource as an object.
	 */

	public static void getAllAccounts() {

		System.out.println("Inside getAllResources() method");

		RestTemplate restTemplate = new RestTemplate();

		final String uri = "http://localhost:8080/bankingapplication/accounts";

		ResponseEntity<SBAccount[]> response = restTemplate.getForEntity(uri, SBAccount[].class);

		SBAccount[] accounts = response.getBody();

		for (int i = 0; i < accounts.length; i++) {

			SBAccount sb = (SBAccount) accounts[i];
			System.out.println("The AccountNo=" + sb.getAccountNo());
			System.out.println("The Account Holder Name=" + sb.getAccountHolderName());
			System.out.println("The Account balance =" + sb.getBalance());

		}
	}
/**
 * postAccounts to add new account to SBAccount
 * 
 * postForObject(uri, request, classType) – POSTs the given object to the URL, and returns the representation found in the response as given class type.
 */
	public static void postAccounts() {
		RestTemplate restTemplate = new RestTemplate();
		final String uri = "http://localhost:8080/bankingapplication/accounts";
		SBAccount sb = new SBAccount(2000, "Diya", 3400);
		SBAccount result = restTemplate.postForObject(uri, sb, SBAccount.class);

	}
/**
 * putAccounts() to update an existing account
 */
	public static void putAccounts() {

		RestTemplate restTemplate = new RestTemplate();

		final String uri = "http://localhost:8080/bankingapplication/accounts/{accNo}";

		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("accNo", 1004);

		SBAccount updatedAccounts = new SBAccount(1004, "Aryagopal", 42000);

		restTemplate.put(uri, updatedAccounts, params);
	}
/**
 * deleteAccounts() to delete a particular account based on accNo
 */
	public static void deleteAccounts() {

		RestTemplate restTemplate = new RestTemplate();

		final String uri = "http://localhost:8080/bankingapplication/accounts/{accNo}";

		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("accNo", 1007);

		restTemplate.delete(uri, params);
	}

}
