/**
 * SBAccount 
 * 
 * SBAccount  extends to Account class it consist of withdrawMoney method and interestCalculation method
 *
 * 30/9/2020
 * 
*/

package com.trainingpractice.account.restclient.model;
/**
 * SBAccount  extends to Account class it consist of withdrawMoney method and interestCalculation method
*/

public class SBAccount extends Account implements Comparable<SBAccount> {

	private int rate;

	private int principal;
	private float duration;
/**
 * Default constructor 
 */
	public SBAccount() {
		System.out.println("Inside SB account no arg constructor");
	}
/**
 * Parameterized constructor
 */
	public SBAccount(int accountNo, String accountHolderName, float balance) {
		super(accountNo, accountHolderName, balance);

		System.out.println("parameterized constructor of sb account");
	}
/**
 * getter method for duration
 */
	public float getDuration() {
		return duration;
	}
	/**
	 * setter method for duration
	 */
	public void setDuration(float duration) {
		this.duration = duration;
	}
	/**
	 * setter method for Rate
	 */
	public void setRate(int rate) {
		this.rate = rate;
	}
	/**
	 * getter method for Principal
	 */
	public int getPrincipal() {
		return principal;
	}
	/**
	 * setter method for Principal
	 */
	public void setPrincipal(int principal) {
		this.principal = principal;
	}
	/* withdrawMoney method to know the withdrawal amount from bank  which throws exception when amountWithdrawn is more than balance*/

//	public void withdrawMoney(float amountWithdrawn) throws InsufficientBalanceException {
//		if (amountWithdrawn > this.balance) {
//			throw new InsufficientBalanceException(amountWithdrawn);
//		} else {
//			this.balance = this.balance - amountWithdrawn;
//			System.out.println("Available balance =" + this.balance);
//		}
//
//	}



	
	public int compareTo(SBAccount o) {

		return this.accountHolderName.compareTo(o.getAccountHolderName());
	}
}


