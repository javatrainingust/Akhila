package com.trainingpractice.account.restclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
