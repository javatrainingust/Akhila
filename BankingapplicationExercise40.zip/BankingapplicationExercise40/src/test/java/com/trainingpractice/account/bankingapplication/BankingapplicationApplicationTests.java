package com.trainingpractice.account.bankingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
