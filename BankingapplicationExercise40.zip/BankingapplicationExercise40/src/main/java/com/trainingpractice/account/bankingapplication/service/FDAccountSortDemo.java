/**
 * FDAccountSortDemo
 * FDAccountSortDemo  is printing all  FDAccounts and also sorted list based on account holder name and Balance
 * 10/6/2020
*/
package com.trainingpractice.account.bankingapplication.service;
/**
 * printing all  FDAccounts and also sorted list based on account holder name and Balance.
 
 */
public class FDAccountSortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FDAccountService fDService=new FDAccountService();
		System.out.println("Print all FD Accounts");
		fDService.getAllFDAccounts();
		
		System.out.println("--------------");
		System.out.println();
		System.out.println("print all account holder name after sorting");
		fDService.getAllFDAccountsSortedByAccountHolderName();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print all accounts after sorting based on balance");
		fDService.getAllFDAccountsSortedByBalance();
	}

}
