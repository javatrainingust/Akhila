/**
	 * LoanAccountRetrival
	 * LoanAccountRetrival is class for retrieving all FDAccounts and also retrieving A particular account
	 * 10/6/2020
	*/

package com.trainingpractice.account.bankingapplication.service;
/**
 * Class for retrieving all LoanAccounts
 */
public class LoanAccountRetrival {
	
	public static void main(String[] args) {
		LoanAccountService service =  new LoanAccountService();
		
		
		/*retrieving all LoanAccounts*/
		
		service.getAllLoanAccounts();
		
		System.out.println("----------------------------------");
		
		
		service.getLoanAccountByAccountNo(1002);

	}
	}


