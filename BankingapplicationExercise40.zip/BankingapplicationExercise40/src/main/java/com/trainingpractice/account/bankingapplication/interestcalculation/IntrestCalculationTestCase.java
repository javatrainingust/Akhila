package com.trainingpractice.account.bankingapplication.interestcalculation;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

class IntrestCalculationTestCase {

	@Test
	void testCalculateInterestFloat() {
		float expectedValue=5.00f;
		IntrestCalculation interestCalc=new IntrestCalculation();
		float actualValue=interestCalc.calculateInterest(1000);
		assertEquals(expectedValue,actualValue,0.0f);
	}

	@Test
	void testCalculateInterestFloatFloat() {
		float expectedValue=7.00f;
		IntrestCalculation interestCalc=new IntrestCalculation();
		float actualValue=interestCalc.calculateInterest(1000, 1);
		assertEquals(expectedValue,actualValue,0.0f);
		
		
	}

}
