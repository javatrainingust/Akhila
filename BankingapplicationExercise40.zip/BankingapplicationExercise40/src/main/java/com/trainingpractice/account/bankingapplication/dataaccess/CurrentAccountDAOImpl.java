/**
 * CurrentAccountDAOImpl
 * CurrentAccountDAOImpl is an implementation class for CurrentAccountDAO
 * 10/6/2020
*/

package com.trainingpractice.account.bankingapplication.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.trainingpractice.account.bankingapplication.model.CurrentAccount;

/**
* Class contains methods for performing getAll ,add ,delete  the current accounts.
*/
@Repository
public class CurrentAccountDAOImpl implements CurrentAccountDAO {
	List<CurrentAccount> currentAccountList;
	private Set currentAccountSet;
	
	/**
	*Constructor of CurrentAccountDAOImpl
	*/
	 public CurrentAccountDAOImpl() {
		 currentAccountList=new ArrayList<CurrentAccount>();
		 currentAccountSet=new HashSet<CurrentAccount>();
		 CurrentAccount ca1=new CurrentAccount(1000,"Akhila",1000,3000);
		 CurrentAccount ca2=new CurrentAccount(1001,"Anjali",1500,2000);
		 CurrentAccount ca3=new CurrentAccount(1002,"Arun",2000,1200);
		 CurrentAccount ca4=new CurrentAccount(1003,"Anu",3000,6000);
		 currentAccountList.add(ca1);
		 currentAccountList.add(ca2);
		 currentAccountList.add(ca3);
		 currentAccountList.add(ca4);
		
	}
/** 
 * getAllCurrentAccounts method is for getting all the CurrentAccount
  */
	
	public List<CurrentAccount> getAllCurrentAccounts() {
		
		return currentAccountList;
	}
	/**
	 *  getCurrentAccountByAccountNo method is for getting the particular  CurrentAccount
	 */

	
	public CurrentAccount getCurrentAccountByAccountNo(int accountNo) {
		CurrentAccount currentAccount=null;
		Iterator<CurrentAccount> iterator=currentAccountList.iterator();
		while (iterator.hasNext()) {
			CurrentAccount currentAccount2 = (CurrentAccount) iterator.next();
			if (currentAccount2.getAccountNo()==accountNo) {
				currentAccount= currentAccount2;
				
			}
			
		}
		return currentAccount;
	}
	/**
	 *  deleteCurrentAccount method is for deleting a particular  CurrentAccount
	 */

	
	public void deleteCurrentAccount(int accountNo) {
		
		CurrentAccount currentAccount=null;
		for (int i = 0; i < currentAccountList.size(); i++) {
			currentAccount = (CurrentAccount)  currentAccountList.get(i);
			if (currentAccount.getAccountNo()==accountNo) {
				currentAccountList.remove(i);
			}	
	}
	

	}
	
	public boolean addCurrentAccount(CurrentAccount currentAccount) {
		boolean  isAdded=currentAccountSet.add(currentAccount);
		if(isAdded) {
			currentAccountList.add(currentAccount);
		}
		return isAdded;
	}
	
	public void updateCurrentAccount(CurrentAccount currentAccount) {
		Iterator<CurrentAccount> iterator=currentAccountList.iterator();
		while (iterator.hasNext()) {
			CurrentAccount ca = (CurrentAccount) iterator.next();
			if(ca.getAccountNo()==currentAccount.getAccountNo()) {
				ca.setAccountHolderName(currentAccount.getAccountHolderName());
				ca.setAccountNo(currentAccount.getAccountNo());
				ca.setOverDraftLimit(currentAccount.getOverDraftLimit());
			
		
	}
	
		} 

}
}