/**
 * BankingapplicationApplication
 * 
 * BankingapplicationApplication  class is used to bootstrap and launch a Spring application from a Java main method. This class automatically creates the ApplicationContext from the classpath, scan the configuration classes and launch the application.
 *
 * 27/10/20
 * 
*/

package com.trainingpractice.account.bankingapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @SpringBootApplication annotation is equivalent to  using @Configuration,@EnableAutoConfiguration,@ComponentScan
 *                       
 */
@SpringBootApplication
public class BankingapplicationApplication {

	public static void main(String[] args) {
		// The main() method uses Spring Boot’s SpringApplication.run() method to run an application
		SpringApplication.run(BankingapplicationApplication.class, args);
	}

}
