/**
 * Renewable
 * 
 * Renewable interface consist of autoRenewal method with no body
 *
 * 30/9/2020
 * 
*/

package com.trainingpractice.account.bankingapplication.model;

public interface Renewable {
	public  void autoRenewal(int tenure); 

}

