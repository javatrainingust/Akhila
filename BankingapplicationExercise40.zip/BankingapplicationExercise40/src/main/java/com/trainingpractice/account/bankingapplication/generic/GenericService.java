/**
 *  GenericService
 * 
 *  GenericService class for performing exception handling
 *
 * 10/9/2020
 * 
*/

package com.trainingpractice.account.bankingapplication.generic;

import com.trainingpractice.account.bankingapplication.model.InsufficientBalanceException;
import com.trainingpractice.account.bankingapplication.model.SBAccount;
/**
 * Class for performing exception handling using try catch block
 */
public class GenericService {
	public static void main(String[] args) {

		SBAccount sb = new SBAccount();
		sb.setAccountHolderName("Sona");
		sb.setAccountNo(1001);
	try {
				sb.withdrawMoney(60000);
			} 
			catch (InsufficientBalanceException e) {
			
				
			System.out.println("You have " + sb.getBalance() + " balance " + e);
			e.printStackTrace();
			}

	}
}
