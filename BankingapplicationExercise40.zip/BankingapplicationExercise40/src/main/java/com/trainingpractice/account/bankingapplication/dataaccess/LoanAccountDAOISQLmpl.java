/**
 * LoanAccountDAOISQLmpl
 * 
 * LoanAccountDAOISQLmpl  implements LoanAccountDAO
 *
 * 23/10/20
 * 
*/
package com.trainingpractice.account.bankingapplication.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trainingpractice.account.bankingapplication.model.LoanAccount;
/**
 * LoanAccountDAOISQLmpl  implements LoanAccountDAO
 * @Repository annotation is used to indicate that the class provides the mechanism for storage, retrieval, search, update and delete operation on objects.
 */
@Repository
public class LoanAccountDAOISQLmpl implements LoanAccountDAO {
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
		/**
		 * @Autowired annotation can be used to autowire bean on the setter method 
		 */
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
		/**
		 * Method to get all loan accounts
		 */
	public List<LoanAccount> getAllLoanAccounts() {
		String SQL = "select * from bankloan";
	      List <LoanAccount> loanacc= jdbcTemplateObject.query(SQL, new LoanAccountMapper());
		
		return loanacc;
	}
	/**
	 * Method to get  loan account by entering a particular accountNo
	 */
	public LoanAccount getLoanAccountByAccountNo(int accountNo) {
		String sql = "select*from bankloan where accountNo = ?";
		 
		LoanAccount loanacc = (LoanAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNo }, new LoanAccountMapper());
      
       return loanacc;
	}
	/**
	 * Method to delete loan account by entering a particular accountNo
	 */
	public void deleteLoanAccount(int accountNo) {
		String query="delete from bankloan where accountNo='"+accountNo+"' ";  
		 jdbcTemplateObject.update(query);  
		
	}
	/**
	 * Method to add  loan account 
	 */
	public boolean addLoanAccount(LoanAccount loanAccount) {
		String sql = "INSERT INTO bankloan" +
	            "(ACCOUNTNO,ACCOUNTHOLDERNAME,BALANCE,LOANOUTSTANDING) VALUES (?, ?, ?,?)";
	  
	        
	  
		jdbcTemplateObject.update(sql, new Object[] {loanAccount.getAccountNo(),loanAccount.getAccountHolderName(),loanAccount.getBalance(),loanAccount.getLoanOutStanding()});
		return true;
	}
	/**
	 * Method to update  loan account by entering a particular accountNo
	 */
	public void updateLoanAccount(LoanAccount loanAccount) {
		
			String query="update bankloan  set  accountNo='"+loanAccount.getAccountNo()+"',accountHolderName='"+loanAccount.getAccountHolderName()+"',balance='"+loanAccount.getBalance()+"' where loanOutStanding='"+loanAccount.getLoanOutStanding()+"' ";  
		    jdbcTemplateObject.update(query);   
		
	}

}
