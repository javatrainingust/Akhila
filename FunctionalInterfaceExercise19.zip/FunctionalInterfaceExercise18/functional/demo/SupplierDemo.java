/**
 * SupplierDemo
 * SupplierDemo is a class  which return a random a number every time.
 * 10/8/2020
*/


package com.trainingpractice.functional.demo;

import java.util.Random;
import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		Supplier<Integer> getRandom = () -> new Random().nextInt(100);
		System.out.println("Random number 1 = " + getRandom.get());

	}

}
