/**
 * PredicateDemo 
 * PredicateDemo  is a class which take an integer argument and check whether the value is greater than 50, if so return true otherwise return false.
 * 10/8/2020
*/


package com.trainingpractice.functional.demo;

import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
				Predicate<Integer> predicate = i -> i > 50;
				boolean greaterCheck = predicate.test(100);
				System.out.println("is 100 greater than 50: "+greaterCheck);
	}

}
