/**
 * ConsumerDemo 
 * ConsumerDemo  is a class take a String argument and convert the each letter of the string into upper case and print it
 * 10/8/2020
*/


package com.trainingpractice.functional.demo;

import java.util.function.Consumer;

public class ConsumerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<String> string = (s) -> System.out.println(s.toUpperCase());
		string.accept("akhila");
	}

}
