/**
 * FunctionDemo
 * FunctionDemo  is a class which take a String argument and convert it in to upper case and return it.
 * 10/8/2020
*/


package com.trainingpractice.functional.demo;

import java.util.function.Function;

public class FunctionDemo {

	public static void main(String[] args) {
		Function<String, String> toUpper = (a) -> {
			return a.toUpperCase();
		};

		System.out.println("akhila to upper case :" + toUpper.apply("akhila"));
	}

}
