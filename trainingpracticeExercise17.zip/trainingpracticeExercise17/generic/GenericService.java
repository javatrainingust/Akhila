package com.trainingpractice.generic;

import com.trainingpractice.calculation.IntrestCalculation;
import com.trainingpractice.model.Account;
import com.trainingpractice.model.CurrentAccount;
import com.trainingpractice.model.FDAccount;
import com.trainingpractice.model.LoanAccount;
import com.trainingpractice.model.SBAccount;

public class GenericService {
	public static void main(String[] args) {
//		FDAccount fd=new FDAccount(3);
//		fd.setAccountHolderName("Arun");
//		fd.setAccountNo(231);
//		
//		SBAccount sb=new SBAccount(1000,2);
//		sb.setAccountHolderName("Sona");
//		sb.setAccountNo(8789);
//		
//		LoanAccount loanAcc=new LoanAccount(2);
//		loanAcc.setAccountNo(2354);
//		loanAcc.setAccountHolderName("arya");
//		CurrentAccount loanacc=new CurrentAccount(1200);
//		loanacc.setAccountNo(2222);
//		loanacc.setAccountHolderName("amalu");
//		Account[] e = {new Account(),fd,sb};
//		IntrestCalculation interest=new IntrestCalculation();
//		for (Account account : e) {
//			account.interestCalculation(2000, interest);
//			if (account instanceof FDAccount) {
//				FDAccount fd1=(FDAccount)account;
//				fd1.autoRenewal(12);
//				
//				
//			}
//			
//
//		
//		
//	}
//
//	}
}
}

 
