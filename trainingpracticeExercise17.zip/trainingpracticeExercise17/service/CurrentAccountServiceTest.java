/**
 * CurrentAccountServiceTest 
 * CurrentAccountServiceTest  is for performing jUnit test operations
 * 10/6/2020
*/

package com.trainingpractice.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.trainingpractice.dataaccess.CurrentAccountDAOImpl;
import com.trainingpractice.model.CurrentAccount;
/** 
 * This class Contains test cases
*/
class CurrentAccountServiceTest {
	List<CurrentAccount> expectedList;
	public CurrentAccountServiceTest() {
		
		expectedList=new ArrayList<CurrentAccount>();	
	 CurrentAccount ca1=new CurrentAccount(1000,"Akhila",1000);
	 CurrentAccount ca2=new CurrentAccount(1001,"Anjali",1500);
	 CurrentAccount ca3=new CurrentAccount(1002,"Arun",2000);
	 CurrentAccount ca4=new CurrentAccount(1003,"Anu",3000);
	 expectedList.add(ca1);
	 expectedList.add(ca2);
	 expectedList.add(ca3);
	 expectedList.add(ca4);
	
}
/**
 * This test case is for  testing whether expected and actual values are same
*/
	@Test
	void testGetAllCurrentAccounts() {
		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();
		List<CurrentAccount> actual = currentAccountDAOImpl.getAllCurrentAccounts();
		List<CurrentAccount> expected = expectedList;
		assertEquals(expected.size(), actual.size());
		

	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testGetCurrentAccountByAccountNo() {
		String expected = "Anu";
		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();
		CurrentAccount actual = currentAccountDAOImpl.getCurrentAccountByAccountNo(1003);
		assertEquals(expected, actual.getAccountHolderName());
		

	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testDeleteCurrentAccount() {
		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();

		currentAccountDAOImpl.deleteCurrentAccount(1002);
		

		List<CurrentAccount> actual = currentAccountDAOImpl.getAllCurrentAccounts();

		assertEquals(expectedList.size() - 1, actual.size());
	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testGetAllCurrentAccountsSortedByAccountHolderName() {
		String expected = "Anjali";
		CurrentAccountService currentService = new CurrentAccountService();
		CurrentAccount actual = currentService.getAllCurrentAccountsSortedByAccountHolderName().get(1);
		assertEquals(expected, actual.getAccountHolderName());
	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testGetAllCurrentAccountsSortedByOverDraftLimit() {
		String expected = "Akhila";
		CurrentAccountService currentService = new CurrentAccountService();
		CurrentAccount actual = currentService.getAllCurrentAccountsSortedByOverDraftLimit().get(0);
		assertEquals(expected, actual.getAccountHolderName());
	}

}
