/**
 * SBAccountService
 * SBAccountService is a service class
 * 10/6/2020
*/
package com.trainingpractice.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.trainingpractice.dataaccess.SBAccountDAO;
import com.trainingpractice.dataaccess.SBAccountDAOImpl;
import com.trainingpractice.model.SBAccount;
/** 
 *class used for add,delete,get the SB Account details
*/
public class SBAccountService {

	SBAccountDAO sBAccountDAOImpl;

	public SBAccountService() {

		sBAccountDAOImpl = new SBAccountDAOImpl();

	}
	/**
	 *  getAllSBAccounts method is for getting all the SBAccount
	*/
	public List<SBAccount> getAllSBAccounts() {

		List<SBAccount> sBAccountList = sBAccountDAOImpl.getAllSBAccounts();
		Iterator<SBAccount> iterator = sBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account No is= " + sb.getAccountNo());
			System.out.println("Accont holder name is = " + sb.getAccountHolderName());
			System.out.println("Account duration is=" + sb.getDuration());
			System.out.println("Account balance is= " + sb.getbalance());

		}

		return sBAccountList;

	}
	/**
	 *  getSBAccountByAccountNo method is for getting the particular  SBAccount
	*/

	public SBAccount getSBAccountByAccountNo(int accountNo) {

		SBAccount sb = sBAccountDAOImpl.getSBAccountByAccountNo(accountNo);

		System.out.println("Account No is= " + sb.getAccountNo());
		System.out.println("Accont holder name is = " + sb.getAccountHolderName());
		System.out.println("Account duration is=" + sb.getDuration());
		System.out.println("Account balance is= " + sb.getbalance());

		return sb;

	}
	/**
	 *  deleteSBAccount method is for deleting a particular  SBAccount
	*/
	public void deleteSBAccount(int accountNo) {

		sBAccountDAOImpl.deleteSBAccount(accountNo);

	}
	/**
	 * method for sorting SBAccounts by account holder name
	 */
	public List<SBAccount> getAllSBAccountsSortedByAccountHolderName() {
		
		List<SBAccount> sBAccountList = sBAccountDAOImpl.getAllSBAccounts();
		Collections.sort(sBAccountList);
		Iterator<SBAccount> iterator = sBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account No is= " + sb.getAccountNo());
			System.out.println("Accont holder name is = " + sb.getAccountHolderName());
			System.out.println("Account duration is=" + sb.getDuration());
			System.out.println("Account balance is= " + sb.getbalance());

		}

		return sBAccountList;
	}
	/**
	 * method for sorting SB account by balance
	 */
	public List<SBAccount> getAllSBAccountsSortedByBalance() {
		List<SBAccount> sBAccountList = sBAccountDAOImpl.getAllSBAccounts();
		Collections.sort(sBAccountList,new SBAccountComparator());
		Iterator<SBAccount> iterator = sBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account No is= " + sb.getAccountNo());
			System.out.println("Accont holder name is = " + sb.getAccountHolderName());
			System.out.println("Account duration is=" + sb.getDuration());
			System.out.println("Account balance is= " + sb.getbalance());

		}

		return sBAccountList;
		
	}
		
		
		
		
		
	

}



