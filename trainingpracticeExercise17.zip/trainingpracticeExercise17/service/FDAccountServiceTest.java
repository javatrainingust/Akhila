/**
 * FDAccountServiceTest
 * FDAccountServiceTest  is for performing JUnit test 
 * 10/6/2020
*/


package com.trainingpractice.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.trainingpractice.dataaccess.FDAccountDAOImpl;

import com.trainingpractice.model.FDAccount;
/** 
 * This class Contains various test cases
*/
class FDAccountServiceTest {
	List<FDAccount> expectedList;

	public FDAccountServiceTest() {

		expectedList = new ArrayList<FDAccount>();
		FDAccount fd1 = new FDAccount(1000, "Akhila",20000);
		FDAccount fd2 = new FDAccount(1001, "Anjali",10000);
		FDAccount fd3 = new FDAccount(1002, "Arun",15000);
		FDAccount fd4 = new FDAccount(1003, "Anu",8000);
		expectedList.add(fd1);
		expectedList.add(fd2);
		expectedList.add(fd3);
		expectedList.add(fd4);

	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testGetAllFDAccounts() {
		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		List<FDAccount> actualList = fDAccountDAOImpl.getAllFDAccounts();

		assertEquals(expectedList.size(), actualList.size());
	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testGetFDAccountByAccountNo() {
		String expectedValue = "Anu";

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();
		

		FDAccount actualValue = fDAccountDAOImpl.getFDAccountByAccountNo(1003);

		assertEquals(expectedValue, actualValue.getAccountHolderName());
	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testDeleteFDAccount() {
		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		fDAccountDAOImpl.deleteFDAccount(1002);
		

		List<FDAccount> actualValue = fDAccountDAOImpl.getAllFDAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());
	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testGetAllFDAccountsSortedByAccountHolderName() {
		String expected = "Akhila";
		FDAccountService fDService = new FDAccountService();
		FDAccount actual = fDService.getAllFDAccountsSortedByAccountHolderName().get(0);
		assertEquals(expected, actual.getAccountHolderName());
	}
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testGetAllFDAccountsSortedByBalance() {
		String expected = "Anjali";
		FDAccountService fDService = new FDAccountService();
		FDAccount actual = fDService.getAllFDAccountsSortedByBalance().get(1);
		assertEquals(expected, actual.getAccountHolderName());
	}

}
