/**
 * CurrentAccountService 
 * CurrentAccountService  is a service class 
 * 10/6/2020
*/

package com.trainingpractice.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.trainingpractice.dataaccess.CurrentAccountDAO;
import com.trainingpractice.dataaccess.CurrentAccountDAOImpl;
import com.trainingpractice.model.CurrentAccount;
/** 
 *class used for add,delete,get the Current account details
*/
public class CurrentAccountService {
	CurrentAccountDAO currentAccountDAOImpl;

	public CurrentAccountService() {

		currentAccountDAOImpl = new CurrentAccountDAOImpl();

	}
	/**
	 * getAllCurrentAccounts method is for getting all the CurrentAccount
	*/
	public List<CurrentAccount> getAllCurrentAccounts() {

		List<CurrentAccount> currentAccountList = currentAccountDAOImpl.getAllCurrentAccounts();
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = iterator.next();

			System.out.println("Account No is= " + ca.getAccountNo());
			System.out.println("Accont holder name is = " + ca.getAccountHolderName());

			System.out.println("Account overdraft limit is="+ca.getOverDraftLimit());

		}

		return currentAccountList;

	}
	/**
	 *  getCurrentAccountByAccountNo method is for getting the particular  CurrentAccount
	*/
	public CurrentAccount getCurrentAccountByAccountNo(int accountNo) {

		CurrentAccount ca = currentAccountDAOImpl.getCurrentAccountByAccountNo(accountNo);

		System.out.println("Account No is= " + ca.getAccountNo());
		System.out.println("Accont holder name is = " + ca.getAccountHolderName());
		//System.out.println("Account tenure is= " + ca.getBalance());
		System.out.println("Account overdraft limit is="+ca.getOverDraftLimit());
		return ca;

	}
	/**
	 *  deleteCurrentAccount method is for deleting a particular  CurrentAccount
	*/
	public void deleteCurrentAccount(int accountNo) {

		currentAccountDAOImpl.deleteCurrentAccount(accountNo);

	}
	
	/**
	*getAllCurrentAccountsSortedByAccountHolderName method for sorting current account by account holder name
	*
	*/
	public List<CurrentAccount> getAllCurrentAccountsSortedByAccountHolderName() {
		List<CurrentAccount> currentAccountList = currentAccountDAOImpl.getAllCurrentAccounts();
		Collections.sort(currentAccountList);
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = iterator.next();

			System.out.println("Account No is= " + ca.getAccountNo());
			System.out.println("Accont holder name is = " + ca.getAccountHolderName());
			//System.out.println("Account balance is =" + ca.getBalance());
			System.out.println("Account over draft limit is ="+ca.getOverDraftLimit());

		}

		return currentAccountList;
	
		
	}
	/**
	*getAllCurrentAccountsSortedByOverDraftLimit method for sorting current account by OverDraftLimit
	*
	*/
	public List<CurrentAccount> getAllCurrentAccountsSortedByOverDraftLimit() {
		List<CurrentAccount> currentAccountList = currentAccountDAOImpl.getAllCurrentAccounts();
		Collections.sort(currentAccountList,new CurrentAccountComparator());
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = iterator.next();

			System.out.println("Account No is= " + ca.getAccountNo());
			System.out.println("Accont holder name is = " + ca.getAccountHolderName());
			//System.out.println("Account balance is =" + ca.getBalance());
			System.out.println("Account over draft limit is ="+ca.getOverDraftLimit());
		}

		return currentAccountList;
		
	}

}

