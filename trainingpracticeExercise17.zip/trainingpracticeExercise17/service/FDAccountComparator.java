/**
 * FDAccountComparator
 * 
 * FDAccountComparator class is implemented from Comparator
 *
 * Date:07/10/2020
 * 
*/


package com.trainingpractice.service;

import java.util.Comparator;

import com.trainingpractice.model.FDAccount;
/**
*Class is for performing sorting balance  in FD accounts .
*/
public class FDAccountComparator implements Comparator<FDAccount> {
	/**
	 * method for sorting balance
	 */
	@Override
	public int compare(FDAccount o1, FDAccount o2) {
		
		return (int)(o1.getBalance()-o2.getBalance());
	}

}
