package com.trainingpractice.dataaccess;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.trainingpractice.model.FDAccount;
/**
 * FDAccountDAOImplTest
 * FDAccountDAOImplTest is a class for performing JUnit testing
 * 10/6/2020
*/
public class FDAccountDAOImplTest {
	List<FDAccount> expectedList;

	public FDAccountDAOImplTest() {

		expectedList = new ArrayList<FDAccount>();
		FDAccount fd1 = new FDAccount(1000, "Akhila",20000);
		FDAccount fd2 = new FDAccount(1001, "Anjali",10000);
		FDAccount fd3 = new FDAccount(1002, "Arun",15000);
		FDAccount fd4 = new FDAccount(1003, "Anu",8000);
		expectedList.add(fd1);
		expectedList.add(fd2);
		expectedList.add(fd3);
		expectedList.add(fd4);

	}

	@Test

	public void testGetAllFDAccounts() {

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		List<FDAccount> actualList = fDAccountDAOImpl.getAllFDAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}

	@Test

	public void testGetFDAccountByAccountNo() {

		String expectedValue = "Anu";

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();
		

		FDAccount actualValue = fDAccountDAOImpl.getFDAccountByAccountNo(1003);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}

	@Test

	public void testDeleteFDAccount() {

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		fDAccountDAOImpl.deleteFDAccount(1002);
		

		List<FDAccount> actualValue = fDAccountDAOImpl.getAllFDAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());

	}

}
