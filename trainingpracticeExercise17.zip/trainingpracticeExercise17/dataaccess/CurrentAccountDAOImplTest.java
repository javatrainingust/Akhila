/**
 * CurrentAccountDAOImplTest
 * CurrentAccountDAOImplTest is a class for performing JUnit testing
 * 10/6/2020
*/
package com.trainingpractice.dataaccess;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.trainingpractice.model.CurrentAccount;

public class CurrentAccountDAOImplTest {

	List<CurrentAccount> expectedList;

	public CurrentAccountDAOImplTest()

	{
		expectedList = new ArrayList<CurrentAccount>();
		CurrentAccount ca1 = new CurrentAccount(1000,"Akhila",1000);
		CurrentAccount ca2 = new CurrentAccount(1001,"Anjali",1500);
		CurrentAccount ca3 = new CurrentAccount(1002,"Arun",2000);
		CurrentAccount ca4 = new CurrentAccount(1003,"Anu",3000);
		expectedList.add(ca1);
		expectedList.add(ca2);
		expectedList.add(ca3);
		expectedList.add(ca4);
	}

	@Test

	public void testGetAllCurrentAccounts() {

		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();

		List<CurrentAccount> actualList = currentAccountDAOImpl.getAllCurrentAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}

	@Test

	public void testGetCurrentAccountsByAccountNo() {

		String expectedValue = "Anu";

		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();

		CurrentAccount actualValue = currentAccountDAOImpl.getCurrentAccountByAccountNo(1003);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}

	@Test

	public void testDeleteCurrentAccount() {

		CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();

		currentAccountDAOImpl.deleteCurrentAccount(1002);
		

		List<CurrentAccount> actualValue = currentAccountDAOImpl.getAllCurrentAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());

	}

}