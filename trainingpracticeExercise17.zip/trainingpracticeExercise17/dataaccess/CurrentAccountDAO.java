/**
 * CurrentAccountDAO
 * CurrentAccountDAO is an interface which contains the methods for implementation class
 * 10/6/2020
*/


package com.trainingpractice.dataaccess;

import java.util.List;

import com.trainingpractice.model.CurrentAccount;
/**
 * CurrentAccountDAO is an interface which contains the methods for implementation class
 */

public interface CurrentAccountDAO {
	public List<CurrentAccount> getAllCurrentAccounts();

	public CurrentAccount getCurrentAccountByAccountNo(int accountNo);

	public void deleteCurrentAccount(int accountNo);

}
