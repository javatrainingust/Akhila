/**
 * LoanAccountDAOImpl
 * LoanAccountDAOImpl is an implementation class for LoanAccountDAO
 * 10/6/2020
*/


package com.trainingpractice.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.trainingpractice.model.LoanAccount;
/**
* Class contains methods for performing getAll ,add ,delete  the current accounts.
*/
public class LoanAccountDAOImpl implements LoanAccountDAO {

	/**
	*Constructor of LoanAccountDAOImpl
	*/
	List<LoanAccount> loanAccountList;

	public LoanAccountDAOImpl() {
		loanAccountList = new ArrayList<LoanAccount>();
		LoanAccount la1 = new LoanAccount(1000, "Akhila", 2000);
		LoanAccount la2 = new LoanAccount(1001, "Sonu", 1000);
		LoanAccount la3 = new LoanAccount(1002, "Arun", 1500);
		LoanAccount la4 = new LoanAccount(1003, "Anu", 4000);
		loanAccountList.add(la1);
		loanAccountList.add(la2);
		loanAccountList.add(la3);
		loanAccountList.add(la4);

	}
	/* getAllLoanAccounts method is for getting all the LoanAccount*/

	@Override
	public List<LoanAccount> getAllLoanAccounts() {
		return loanAccountList;
	}
	/* getLoanAccountByAccountNo method is for getting the particular  LoanAccount*/

	@Override
	public LoanAccount getLoanAccountByAccountNo(int accountNo) {
		LoanAccount loanAccount = null;
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		while (iterator.hasNext()) {
			LoanAccount loanAccount2 = (LoanAccount) iterator.next();
			if (loanAccount2.getAccountNo() == accountNo) {
				loanAccount = loanAccount2;

			}

		}
		return loanAccount;
	}
	/* deleteLoanAccount method is for deleting a particular  LoanAccount*/

	@Override
	public void deleteLoanAccount(int accountNo) {
		// TODO Auto-generated method stub
		LoanAccount loanAccount = null;
		for (int i = 0; i < loanAccountList.size(); i++) {
			loanAccount = (LoanAccount) loanAccountList.get(i);
			if (loanAccount.getAccountNo() == accountNo) {
				loanAccountList.remove(i);
			}

		}
	}
}
