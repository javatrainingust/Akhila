package com.trainingpractice.dataaccess;

import java.util.List;

import com.trainingpractice.model.FDAccount;
/**
 * FDAccountDAO 
 * FDAccountDAO is an interface which contains the methods  for implementation class
 * 10/6/2020
*/

public interface FDAccountDAO {
	public List<FDAccount> getAllFDAccounts();

	public FDAccount getFDAccountByAccountNo(int accountNo);

	public void deleteFDAccount(int accountNo);

}
