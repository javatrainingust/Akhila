package com.trainingpractice.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.trainingpractice.model.SBAccount;
/**
 * SBAccountDAOImpl
 * SBAccountDAOImpl is an implementation class for SBAccountDAO
 * 10/6/2020
*/
public class SBAccountDAOImpl implements SBAccountDAO {
	List<SBAccount> sBAccountList;

	public SBAccountDAOImpl() {
		sBAccountList = new ArrayList<SBAccount>();
		SBAccount sb1 = new SBAccount(1000, "akhila", 2000, 2);
		SBAccount sb2 = new SBAccount(1001, "Anjali", 1000, 3);
		SBAccount sb3 = new SBAccount(1002, "Arun", 1500, 5);
		SBAccount sb4 = new SBAccount(1003, "Anu", 5000, 3);
		sBAccountList.add(sb1);
		sBAccountList.add(sb2);
		sBAccountList.add(sb3);
		sBAccountList.add(sb4);

	}
	/* getAllSBAccounts method is for getting all the SBAccount*/

	@Override
	public List<SBAccount> getAllSBAccounts() {

		return sBAccountList;
	}
	/* getSBAccountByAccountNo method is for getting the particular  SBAccount*/

	@Override
	public SBAccount getSBAccountByAccountNo(int accountNo) {
	
		SBAccount sBAccount = null;
		Iterator<SBAccount> iterator = sBAccountList.iterator();
		while (iterator.hasNext()) {
			SBAccount sBAccount2 = (SBAccount) iterator.next();
			if (sBAccount2.getAccountNo() == accountNo) {
				sBAccount = sBAccount2;

			}

		}
		return sBAccount;
	}
	/* deleteSBAccount method is for deleting a particular  SBAccount*/

	@Override
	public void deleteSBAccount(int accountNo) {
		SBAccount sBAccount = null;
		for (int i = 0; i < sBAccountList.size(); i++) {
			sBAccount = (SBAccount) sBAccountList.get(i);
			if (sBAccount.getAccountNo() == accountNo) {
				sBAccountList.remove(i);
			}

		}
	}
}
	