package com.trainingpractice.dataaccess;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.trainingpractice.model.FDAccount;
/**
 * FDAccountDAOImplTest
 * FDAccountDAOImplTest is a class for performing JUnit testing
 * 10/6/2020
*/
public class FDAccountDAOImplTest {
	List expectedList;

	public FDAccountDAOImplTest() {

		expectedList = new ArrayList<FDAccount>();
		FDAccount fd1 = new FDAccount(1000, "akhila", 2);
		FDAccount fd2 = new FDAccount(1001, "Anjali", 3);
		FDAccount fd3 = new FDAccount(1002, "Arun", 4);
		FDAccount fd4 = new FDAccount(1003, "Anu", 5);
		expectedList.add(fd1);
		expectedList.add(fd2);
		expectedList.add(fd3);
		expectedList.add(fd4);

	}

	@Test

	public void testGetAllFDAccounts() {

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		List actualList = fDAccountDAOImpl.getAllFDAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}

	@Test

	public void testGetFDAccountByAccountNo() {

		String expectedValue = "Anu";

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		FDAccount actualValue = fDAccountDAOImpl.getFDAccountByAccountNo(1003);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}

	@Test

	public void testDeleteFDAccount() {

		FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();

		fDAccountDAOImpl.deleteFDAccount(1002);
		;

		List actualValue = fDAccountDAOImpl.getAllFDAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());

	}

}
