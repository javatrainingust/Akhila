package com.trainingpractice.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.trainingpractice.model.CurrentAccount;

/**
 * CurrentAccountDAOImpl
 * CurrentAccountDAOImpl is an implementation class for CurrentAccountDAO
 * 10/6/2020
*/
public class CurrentAccountDAOImpl implements CurrentAccountDAO {
	List<CurrentAccount> currentAccountList;
	 public CurrentAccountDAOImpl() {
		 currentAccountList=new ArrayList<CurrentAccount>();	
		 CurrentAccount ca1=new CurrentAccount(1000,"akhila",2000);
		 CurrentAccount ca2=new CurrentAccount(1001,"Anjali",1000);
		 CurrentAccount ca3=new CurrentAccount(1002,"Arun",1500);
		 CurrentAccount ca4=new CurrentAccount(1003,"Anu",5000);
		 currentAccountList.add(ca1);
		 currentAccountList.add(ca2);
		 currentAccountList.add(ca3);
		 currentAccountList.add(ca4);
		
	}
/* getAllCurrentAccounts method is for getting all the CurrentAccount*/
	@Override
	public List<CurrentAccount> getAllCurrentAccounts() {
		
		return currentAccountList;
	}
	/* getCurrentAccountByAccountNo method is for getting the particular  CurrentAccount*/

	@Override
	public CurrentAccount getCurrentAccountByAccountNo(int accountNo) {
		CurrentAccount currentAccount=null;
		Iterator<CurrentAccount> iterator=currentAccountList.iterator();
		while (iterator.hasNext()) {
			CurrentAccount currentAccount2 = (CurrentAccount) iterator.next();
			if (currentAccount2.getAccountNo()==accountNo) {
				currentAccount= currentAccount2;
				
			}
			
		}
		return currentAccount;
	}
	/* deleteCurrentAccount method is for deleting a particular  CurrentAccount*/

	@Override
	public void deleteCurrentAccount(int accountNo) {
		
		CurrentAccount currentAccount=null;
		for (int i = 0; i < currentAccountList.size(); i++) {
			currentAccount = (CurrentAccount)  currentAccountList.get(i);
			if (currentAccount.getAccountNo()==accountNo) {
				currentAccountList.remove(i);
			}	
	}

	}

}