package com.trainingpractice.service;
/**
 * FDAccountRetrival
 * FDAccountRetrival is class for retrieving all FDAccounts and also retrieving A particular account
 * 10/6/2020
*/
public class FDAccountRetrival {

	public static void main(String[] args) {
		FDAccountService service = new FDAccountService();

		/* retrieving all FDAccounts */

		service.getAllFDAccounts();

		System.out.println("----------------------------------");

		service.getFDAccountByAccountNo(1002);

	}

}
