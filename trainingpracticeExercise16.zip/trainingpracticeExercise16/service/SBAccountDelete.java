package com.trainingpractice.service;
/**
 *  SBAccountDelete 
 *  SBAccountDelete is class for retrieving all FDAccounts before deletion and also deleting  a particular account
 * 10/6/2020
*/
public class SBAccountDelete {

	public static void main(String[] args) {
		SBAccountService service =  new SBAccountService();
		
		System.out.println();
		System.out.println("all SBAccounts are retrieved");
		
		service.getAllSBAccounts();
				
		
		service.deleteSBAccount(1003);
		System.out.println("----------------------------------");
		
		System.out.println();
		System.out.println("After deletion");
		
		service.getAllSBAccounts();


	}

}
