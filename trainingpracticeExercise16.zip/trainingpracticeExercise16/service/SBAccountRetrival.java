package com.trainingpractice.service;

public class SBAccountRetrival {
	/**
	 *  SBAccountRetrival
	 *  SBAccountRetrival is class for retrieving all FDAccounts and also retrieving A particular account
	 * 10/6/2020
	*/
	public static void main(String[] args) {
		SBAccountService service =  new SBAccountService();
		
		
		/*retrieving all SBAccounts*/
		
		service.getAllSBAccounts();
		
		System.out.println("----------------------------------");
		
		
		service.getSBAccountByAccountNo(1002);

	}

	}


