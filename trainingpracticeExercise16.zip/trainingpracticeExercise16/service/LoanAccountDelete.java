package com.trainingpractice.service;
/**
 * LoanAccountDelete 
 * LoanAccountDelete is class for retrieving all FDAccounts before deletion and also deleting  a particular account
 * 10/6/2020
*/
public class LoanAccountDelete {

	public static void main(String[] args) {
		LoanAccountService service =  new LoanAccountService();
		
		System.out.println();
		System.out.println("all LoanAccounts are retrieved");
		
		service.getAllLoanAccounts();
				
		
		service.deleteLoanAccount(1000);
		System.out.println("----------------------------------");
		
		System.out.println();
		System.out.println("After deletion");
		
		service.getAllLoanAccounts();


	}

}
