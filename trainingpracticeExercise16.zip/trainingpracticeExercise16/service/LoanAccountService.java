package com.trainingpractice.service;

import java.util.Iterator;
import java.util.List;

import com.trainingpractice.dataaccess.LoanAccountDAO;
import com.trainingpractice.dataaccess.LoanAccountDAOImpl;
import com.trainingpractice.model.LoanAccount;

public class LoanAccountService {
	LoanAccountDAO loanAccountDAOImpl;

	public LoanAccountService() {

		loanAccountDAOImpl = new LoanAccountDAOImpl();

	}
	/* getAllLoanAccounts method is for getting all the LoanAccount*/
	public List<LoanAccount> getAllLoanAccounts() {

		List loanAccountList = loanAccountDAOImpl.getAllLoanAccounts();
		Iterator<LoanAccount> iterator = loanAccountList.iterator();

		while (iterator.hasNext()) {

			LoanAccount la = iterator.next();

			System.out.println("Account No is= " + la.getAccountNo());
			System.out.println("Accont holder name is = " + la.getAccountHolderName());
			System.out.println("Account balance is =" + la.getBalance());

		}

		return loanAccountList;

	}
	/* getLoanAccountByAccountNo method is for getting the particular  LoanAccount*/
	public LoanAccount getLoanAccountByAccountNo(int accountNo) {

		LoanAccount la = loanAccountDAOImpl.getLoanAccountByAccountNo(accountNo);

		System.out.println("Account No is= " + la.getAccountNo());
		System.out.println("Accont holder name is = " + la.getAccountHolderName());
		System.out.println("Account tenure is= " + la.getTenure());
		return la;

	}
	/* deleteLoanAccount method is for deleting a particular  LoanAccount*/
	public void deleteLoanAccount(int accountNo) {

		loanAccountDAOImpl.deleteLoanAccount(accountNo);

	}

}

