package com.trainingpractice.service;

import java.util.Iterator;
import java.util.List;

import com.trainingpractice.dataaccess.CurrentAccountDAO;
import com.trainingpractice.dataaccess.CurrentAccountDAOImpl;
import com.trainingpractice.model.CurrentAccount;
/**
 * CurrentAccountService 
 * CurrentAccountService  is a service class 
 * 10/6/2020
*/
public class CurrentAccountService {
	CurrentAccountDAO currentAccountDAOImpl;

	public CurrentAccountService() {

		currentAccountDAOImpl = new CurrentAccountDAOImpl();

	}
	/* getAllCurrentAccounts method is for getting all the CurrentAccount*/
	public List<CurrentAccount> getAllCurrentAccounts() {

		List currentAccountList = currentAccountDAOImpl.getAllCurrentAccounts();
		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = iterator.next();

			System.out.println("Account No is= " + ca.getAccountNo());
			System.out.println("Accont holder name is = " + ca.getAccountHolderName());
			System.out.println("Account balance is =" + ca.getBalance());

		}

		return currentAccountList;

	}
	/* getCurrentAccountByAccountNo method is for getting the particular  CurrentAccount*/
	public CurrentAccount getCurrentAccountByAccountNo(int accountNo) {

		CurrentAccount ca = currentAccountDAOImpl.getCurrentAccountByAccountNo(accountNo);

		System.out.println("Account No is= " + ca.getAccountNo());
		System.out.println("Accont holder name is = " + ca.getAccountHolderName());
		System.out.println("Account tenure is= " + ca.getBalance());
		return ca;

	}
	/* deleteCurrentAccount method is for deleting a particular  CurrentAccount*/
	public void deleteCurrentAccount(int accountNo) {

		currentAccountDAOImpl.deleteCurrentAccount(accountNo);

	}

}

