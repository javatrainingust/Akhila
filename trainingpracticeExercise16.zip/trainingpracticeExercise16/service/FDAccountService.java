package com.trainingpractice.service;

import java.util.Iterator;
import java.util.List;

import com.trainingpractice.dataaccess.FDAccountDAO;
import com.trainingpractice.dataaccess.FDAccountDAOImpl;
import com.trainingpractice.model.FDAccount;
/**
 * FDAccountService
 * FDAccountService is a service class
 * 10/6/2020
*/
public class FDAccountService {
	FDAccountDAO fDAccountDAOImpl;

	public FDAccountService() {

		fDAccountDAOImpl = new FDAccountDAOImpl();

	}
	/* getAllFDAccounts method is for getting all the FDAccount*/
	public List<FDAccount> getAllFDAccounts() {

		List fDAccountList = fDAccountDAOImpl.getAllFDAccounts();
		Iterator<FDAccount> iterator = fDAccountList.iterator();

		while (iterator.hasNext()) {

			FDAccount fd = iterator.next();

			System.out.println("Account No is= " + fd.getAccountNo());
			System.out.println("Accont holder name is = " + fd.getAccountHolderName());
			System.out.println("Account tenure is= " + fd.getTenure());

		}

		return fDAccountList;

	}
	/* getFDAccountByAccountNo method is for getting the particular  FDAccount*/
	public FDAccount getFDAccountByAccountNo(int accountNo) {

		FDAccount fd = fDAccountDAOImpl.getFDAccountByAccountNo(accountNo);

		System.out.println("Account No is= " + fd.getAccountNo());
		System.out.println("Accont holder name is = " + fd.getAccountHolderName());
		System.out.println("Account tenure is= " + fd.getTenure());
		return fd;

	}
	/* deleteFDAccount method is for deleting a particular  FDAccount*/
	public void deleteFDAccount(int accountNo) {

		fDAccountDAOImpl.deleteFDAccount(accountNo);

	}

}
