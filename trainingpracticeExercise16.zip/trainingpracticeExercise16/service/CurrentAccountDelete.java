package com.trainingpractice.service;
/**
 *  CurrentAccountDelete 
 *  CurrentAccountDelete is class for retrieving all FDAccounts before deletion and also deleting  a particular account
 * 10/6/2020
*/
public class CurrentAccountDelete {

	public static void main(String[] args) {
		CurrentAccountService service =  new CurrentAccountService();
		
		System.out.println();
		System.out.println("all current Accounts are retrieved");
		
		service.getAllCurrentAccounts();
				
		
		service.deleteCurrentAccount(1003);
		System.out.println("----------------------------------");
		
		System.out.println();
		System.out.println("After deletion");
		
		service.getAllCurrentAccounts();


	}

}
