/**
 * LoanAccount
 * 
 * LoanAccount extends to Account class it consist of calculateEMI method
 *
 
*/

package com.trainingpractice.model;
/**
 *class to perform LoanAccount operations
*/


public class LoanAccount extends Account{
	private float emi;
	private float loanOutStanding;
	 int tenure=12;
	
	public LoanAccount() {
		
		System.out.println("Inside loan account no arg constructor");
	}
	
	
	public LoanAccount(int accountNo, String accountHolderName,int tenure) {
		super(accountNo,accountHolderName);
		this.tenure = tenure;
		System.out.println("inside parameterized constructor of loan account");
	}

	
	public int getTenure() {
		return tenure;
	}


	public void setTenure(int tenure) {
		this.tenure = tenure;
	}


	public float getEmi() {
		return emi;
	}


	public void setEmi(float emi) {
		this.emi = emi;
	}


	public float getLoanOutStanding() {
		return loanOutStanding;
	}
	public void setLoanOutStanding(float loanOutStanding) {
		this.loanOutStanding = loanOutStanding;
	}
	
	public void calculateEMI(float  loanTakenFromBank) {
		
		emi= loanTakenFromBank/tenure;
		loanOutStanding=loanTakenFromBank-emi;
		System.out.println("EMI for this Account is="+emi);
	}

}


