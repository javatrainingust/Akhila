/**
 * CurrentAccount
 * 
 * CurrentAccount extends to Account class it consist of AmountLimit method
 *
 * 30/9/2020
 * 
*/

package com.trainingpractice.model;

/**
 * class to perform account operation of CurrentAccount
*/
public class CurrentAccount extends Account {
	public float overDraftLimit;
	float balance = 5000;

	public CurrentAccount() {

		System.out.println("Inside current account no arg constructor");
	}

	public CurrentAccount(int accountNo, String accountHolderName,float balance) {
		super(accountNo,accountHolderName);
		this.balance = balance;
		System.out.println("inside parameterized constructor of current account");
	}

	public float getOverDraftLimit() {
		return overDraftLimit;
	}

	public void AmountLimit(float balance) {
		if (balance < overDraftLimit) {
			System.out.println("Eligible for overdraft");
		} else {
			System.out.println("Not eligible for overdrafting");
		}
   
	}

}                                 
	
