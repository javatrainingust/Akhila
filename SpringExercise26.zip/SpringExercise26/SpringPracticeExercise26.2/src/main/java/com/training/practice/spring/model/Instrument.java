
/**
 *Instrument
 * 
 *Instrument class is an interface
 * 
 * 12/10/2020
 * 
 */
package com.training.practice.spring.model;
/**
 * Contains of play method
 */
public interface Instrument {
	public void play();

}
