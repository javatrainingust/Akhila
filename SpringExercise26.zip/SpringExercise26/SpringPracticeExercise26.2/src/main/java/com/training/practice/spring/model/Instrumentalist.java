
/**
 * Instrumentalist 
 * 
 *Instrumentalist  class  for dependency injection through setter method
 *
 *
 */
package com.training.practice.spring.model;

/**
 * Instrumentalist implements performer interface
 */

public class Instrumentalist implements Performer {

	Saxophone saxophon;
	
	/**
	 * get method
	 */
	public Saxophone getSaxophon() {
		return saxophon;
	}

	/**
	 * setter method for dependency injection
	 */
	public void setSaxophon(Saxophone saxophon) {
		this.saxophon = saxophon;
	}

	/**
	 * implementation of performer interface
	 */
	public void perform() {
		
		this.saxophon.play();
	}

}

