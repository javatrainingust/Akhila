/**
 * PerformanceDemo
 * 
 * PerformanceDemo class for Dependency injection demo
 * 
 * 12/10/2020
 */

package com.training.practice.spring.model;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Dependency injection through constructor demo
 */
public class PerformanceDemo {

	public static void main(String[] args) {

		/* loading the definitions from the given XML file */
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		
		/* Dependency Injection through setter method */
		Instrumentalist instrumentalist = context.getBean("instrumentalistObj", Instrumentalist.class);

		instrumentalist.perform();
		

		
	}

}
