/**
 *Saxophone
 * 
 * Saxophone class for Dependency injection using setter method
 * 
 * 12/10/2020
 */


package com.training.practice.spring.model;

/**
 *Saxophone implements instrument interface
 */

public class Saxophone implements Instrument {
	
	/**
	 * Play method to display
	 */
	public void play() {

		System.out.println("playing started by saxophone");
		
	}

}
