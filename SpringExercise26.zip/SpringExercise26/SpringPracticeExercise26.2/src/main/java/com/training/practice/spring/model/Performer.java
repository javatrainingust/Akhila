/**
 *Performer
 * 
 * Performer class is an interface
 * 
 * 12/10/2020
 * 
 */

package com.training.practice.spring.model;
/**
 *Consist of One method perform 
 */
public interface Performer {
	public void perform();

}
