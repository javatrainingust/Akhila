/**
 * SpringConfig
 * SpringConfig is a class for spring configuration
 * 13-10-2020
 */

package com.training.practice.spring.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * SpringConfig is a class for spring configuration
 */
@Configuration
public class SpringConfiguration {
	@Bean(name = "instrumentalistObj")
	/**
	 * method to returns instrumentList
	 */
	public Instrumentalist getInstrumentalist() {
		System.out.println("Inside getInstrumentalist method");
		Instrumentalist instrument = new Instrumentalist();
		instrument.setSaxophon(getSaxophone());
		return instrument;

	}

	/**
	 * Method that returns saxophoneObj
	 */
	@Bean

	public Saxophone getSaxophone() {

		System.out.println("Inside getSaxophone method");

		Saxophone saxophoneObj = new Saxophone();

		return saxophoneObj;

	}

}
