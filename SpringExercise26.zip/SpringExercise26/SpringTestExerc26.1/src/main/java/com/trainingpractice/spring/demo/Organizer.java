/**
 * Organizer
 * 
 * Organizer class for for Spring World Talent Competition.
 * 
 * 13/10/2020
 */

package com.trainingpractice.spring.demo;

/**
 * Spring Component annotation is used to denote a class as Component
 */

public class Organizer {
	/**
	 * Default Constructor of organizer class
	 */
	public Organizer() {

	}

	/**
	 * sayGreeting Method to print Welcome to the talent competition
	 */
	public void sayGreetings() {
		System.out.println("Welcome to the talent competion");
	}

}
