/**
 * SpringConfig
 * SpringConfig is a class spring configuration
 * 13-10-2020
 */

package com.trainingpractice.spring.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
/**
 * SpringConfig is a class spring configuration
 */
@Configuration
public class SpringConfig {

	/**
	 * getOrganizer is a method that returns organizer object
	 */

	@Bean(name ="organizer")
	public Organizer getOrganizer() {

		System.out.println("inside getOrganizer() method of SpringConfig class");

		Organizer org = new Organizer();
		return org;
	}

}
