package com.trainingpractice.account.bankingapplication.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.trainingpractice.account.bankingapplication.model.FDAccount;
import com.trainingpractice.account.bankingapplication.model.SBAccount;
/**
 * SBAccountDAOImpl
 * SBAccountDAOImpl is an implementation class for SBAccountDAO
 * 10/6/2020
*/

public class SBAccountDAOImpl implements SBAccountDAO {
	List<SBAccount> sBAccountList;
	private Set sBAccountSet;
	public SBAccountDAOImpl() {
		sBAccountList = new ArrayList<SBAccount>();
		sBAccountSet= new HashSet<SBAccount>();
		
		SBAccount sb1 = new SBAccount(1000, "Akhila", 2000);
		SBAccount sb2 = new SBAccount(1001, "Anjali", 1000);
		SBAccount sb3 = new SBAccount(1002, "Arun", 1500);
		SBAccount sb4 = new SBAccount(1003, "Anu", 5000);
		sBAccountList.add(sb1);
		sBAccountList.add(sb2);
		sBAccountList.add(sb3);
		sBAccountList.add(sb4);
		 

	}
	/* getAllSBAccounts method is for getting all the SBAccount*/

	
	public List<SBAccount> getAllSBAccounts() {

		return sBAccountList;
	}
	/* getSBAccountByAccountNo method is for getting the particular  SBAccount*/

	
	public SBAccount getSBAccountByAccountNo(int accountNo) {
	
		SBAccount sBAccount = null;
		Iterator<SBAccount> iterator = sBAccountList.iterator();
		while (iterator.hasNext()) {
			SBAccount sBAccount2 = (SBAccount) iterator.next();
			if (sBAccount2.getAccountNo() == accountNo) {
				sBAccount = sBAccount2;

			}

		}
		return sBAccount;
	}
	/* deleteSBAccount method is for deleting a particular  SBAccount*/

	
	public void deleteSBAccount(int accountNo) {
		SBAccount sBAccount = null;
		for (int i = 0; i < sBAccountList.size(); i++) {
			sBAccount = (SBAccount) sBAccountList.get(i);
			if (sBAccount.getAccountNo() == accountNo) {
				sBAccountList.remove(i);
			}

		}
	}


	public boolean addSBAccount(SBAccount sBAccount) {
		boolean  isAdded=sBAccountSet.add(sBAccount);
		if(isAdded) {
			sBAccountList.add(sBAccount);
		}
		return isAdded;
	}

	
	public void updateSBAccount(SBAccount sBAccount) {
		Iterator<SBAccount> iterator=sBAccountList.iterator();
		while (iterator.hasNext()) {
			SBAccount sb = (SBAccount) iterator.next();
			if(sb.getAccountNo()==sBAccount.getAccountNo()) {
				sb.setAccountHolderName(sBAccount.getAccountHolderName());
				sb.setAccountNo(sBAccount.getAccountNo());
				sb.setBalance(sBAccount.getBalance());
				
		
	}
}
	}
}
	