package com.trainingpractice.account.bankingapplication.dataaccess;

import java.util.List;

import com.trainingpractice.account.bankingapplication.model.FDAccount;
/**
 * FDAccountDAO 
 * FDAccountDAO is an interface which contains the methods  for implementation class
 * 10/6/2020
*/

public interface FDAccountDAO {
	public List<FDAccount> getAllFDAccounts();

	public FDAccount getFDAccountByAccountNo(int accountNo);

	public void deleteFDAccount(int accountNo);
	public boolean addFDAccount(FDAccount fDAccount);
	public void updateFDAccount(FDAccount fDAccount);

}
