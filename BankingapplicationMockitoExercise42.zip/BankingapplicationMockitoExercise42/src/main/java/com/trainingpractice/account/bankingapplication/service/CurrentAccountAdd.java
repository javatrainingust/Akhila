/**
 *  CurrentAccountAdd 
 *  CurrentAccountAdd  is an class for printing the account details after adding and updating 
 * 10/8/2020
*/

package com.trainingpractice.account.bankingapplication.service;

import com.trainingpractice.account.bankingapplication.model.CurrentAccount;
/**
 * Main method for printing the account details after adding and updating 
 */

public class CurrentAccountAdd {

	public static void main(String[] args) {
		CurrentAccountService service=new CurrentAccountService();
		service.addCurrentAccount(new CurrentAccount(1000, "Akhila",20000,3000));
		service.addCurrentAccount(new CurrentAccount(1001, "Anjali", 10000,2000));
		System.out.println("Printing all Accounts");	
		service.getAllCurrentAccounts();
		
		System.out.println("---------------------------------------------");	
	service.updateCurrentAccount(new CurrentAccount(1001, "Anjali", 50000,2000));
		
		System.out.println("Printing all updated accounts");	
	service.getAllCurrentAccounts();
	}
}