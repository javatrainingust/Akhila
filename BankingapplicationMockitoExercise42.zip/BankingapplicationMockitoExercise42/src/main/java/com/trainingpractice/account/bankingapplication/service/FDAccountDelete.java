/**
 * FDAccountDelete
 * FDAccountDelete is class for retrieving all FDAccounts before deletion and also deleting  a particular account
 * 10/6/2020
*/

package com.trainingpractice.account.bankingapplication.service;
/**
 * Class for retrieving all FDAccount and deleting a particular FDaccount and results printed
 */
public class FDAccountDelete {

	public static void main(String[] args) {
		FDAccountService service =  new FDAccountService();
		
		System.out.println();
		System.out.println("all FDAccounts are retrieved");
		
		service.getAllFDAccounts();
				
		
		service.deleteFDAccount(1003);
		System.out.println("----------------------------------");
		
		System.out.println();
		System.out.println("After deletion");
		
		service.getAllFDAccounts();

	}


	}


