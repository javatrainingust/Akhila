/**
 * SBAccountController
 * 
 * SBAccountController  @Restcontroller annotation is used to declare the class as a controller
 *
 * 27/10/20
 * 
*/

package com.trainingpractice.account.bankingapplication.controller;

import com.trainingpractice.account.bankingapplication.model.SBAccount;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trainingpractice.account.bankingapplication.service.SBAccountService;

/**
 *@RestController is a specialized version of the controller. It includes the @Controller and @ResponseBody annotations and as a result, simplifies the controller implementation
*/
@RestController
public class SBAccountController {
	@Autowired
	private SBAccountService service;
	/**
	 * showSBAccountform method which returns addSBAccount jsp
	 */
	/*
	 * @RequestMapping("/showSBAccountform")
	 * 
	 * public String showSBAccountAccountForm(Model model) {
	 * 
	 * SBAccount sBAccount = new SBAccount();
	 * 
	 * model.addAttribute("key", sBAccount); return "addSBAccount";
	 * 
	 * 
	 * }
	 */
/**
 * addSBAccount to add a particular SB account,@PostMapping is used to handle POST type of request method
 */
	@PostMapping("/accounts")
	public SBAccount addSBAccount(@RequestBody SBAccount sBAccount) {
		
		
		service.addSBAccount(sBAccount);
		
		//return "redirect:/sBAccounts";
		return sBAccount;
		
	}
	/**
	 * updateSBAccount to update a particular SB account,@PutMapping annotation for mapping HTTP PUT requests onto specific handler methods.
	 */
	@PutMapping("/accounts/{accNo}")
	public SBAccount updateSBAccount(@PathVariable int accNo ,@RequestBody SBAccount sBAccount) {
		
		SBAccount oldSB=service.getSBAccountByAccountNo(accNo);
		if (oldSB!=null) {
			service.updateSBAccount(sBAccount);
		}
		
		
		return sBAccount;
		
		
	}
	/**
	 * addAccount to get all SB account,@GetMapping annotation maps HTTP GET requests onto specific handler methods.
	 */
	
	@GetMapping("/accounts")

	
	public List<SBAccount> getAllSBAccounts() {
		
		List<SBAccount> sBAccountList = service.getAllSBAccounts();
		
		return sBAccountList;
	}
	/**
	 * getAccountsBasedOnBalance to get SB account by balance,@GetMapping annotation maps HTTP GET requests onto specific handler methods.
	 */
@GetMapping("/accounts-account/{balance}") 
	
	public List<SBAccount> getAccountsBasedOnBalance(@PathVariable float balance){

		
		List<SBAccount> sBAccountList = service.getAccountsBasedOnBalance(balance);
		
				return sBAccountList;
}
	/**
	 * get account by entering a particular accNo,@GetMapping annotation maps HTTP GET requests onto specific handler methods.
	 */
	@GetMapping("/accounts/{accNo}")
	public SBAccount getSBAccount(@PathVariable int accNo) {
		SBAccount sBAccount=service.getSBAccountByAccountNo(accNo);
		return sBAccount;
	}
	
		
	/**
	 * getSBAccount is  a method to display particular account details .
	 */	
	@RequestMapping("/viewSBAccount")
	public String getSBAccount(@RequestParam("accNo") String accNo,Model model ) {
	
		SBAccount sBAccount=service.getSBAccountByAccountNo(Integer.parseInt(accNo));
	model.addAttribute("key",sBAccount);
	return "viewSBAccount";
	
}
	/**
	 * getAllSBAccountsSortByName to sort the accounts by name 
	 */
@RequestMapping("/sortSBAccountByName")
	
	public String getAllSBAccountsSortByName(Model model){
	System.out.println("Inside controller getAllSBAccountsSortByName");
		
		List<SBAccount> accountList = service.getAllSBAccountsSortedByAccountHolderName();
		
		model.addAttribute("sBAccounts",accountList );
		
		
		return "SBAccountsList";
		
	}
/**
 *getAllSBAccountSortByBalance sort accounts based on balance
 */
	@RequestMapping("/sortSBAccountsByBalance")	
	public String getAllSBAccountSortByBalance(Model model){
	System.out.println("Inside controller getAllSBAccountsSortByBalance");
		
		List<SBAccount> sBAccount = service.getAllSBAccountsSortedByBalance();
		
		model.addAttribute("sBAccounts",sBAccount);
		
		
		return "sBAccountsList";
		
	}
	/**
	 * deleteSBAccount is to delete a particular account,@DeleteMapping annotation maps HTTP DELETE requests onto specific handler methods.
	 */
	@DeleteMapping("/accounts/{accNo}")
	public void deleteSBAccount(@PathVariable int accNo) {
		
		
		service.deleteSBAccount(accNo);
		
				
		
		
		
}
}
