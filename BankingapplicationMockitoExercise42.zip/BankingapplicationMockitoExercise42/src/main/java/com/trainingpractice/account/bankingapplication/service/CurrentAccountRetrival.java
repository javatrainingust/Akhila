/**
	 * CurrentAccountRetrival
	 * CurrentAccountRetrival is class for retrieving all FDAccounts and also retrieving A particular account
	 * 10/6/2020
	*/
package com.trainingpractice.account.bankingapplication.service;
/**
 * Class for retrieving all CurrentAccounts 
*/
public class CurrentAccountRetrival {
	
	public static void main(String[] args) {
		 CurrentAccountService service =  new  CurrentAccountService();
		
		
		/*retrieving all CurrentAccounts*/
		
		service.getAllCurrentAccounts();
		
		System.out.println("----------------------------------");
		
		
		service.getCurrentAccountByAccountNo(1002);

	}

	}


