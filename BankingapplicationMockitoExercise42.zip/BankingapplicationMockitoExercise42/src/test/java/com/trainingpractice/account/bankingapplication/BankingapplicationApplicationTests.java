/**
 * BankingapplicationApplicationTests
 * BankingapplicationApplicationTests is a class for performing JUnit testing
 * 28/10/2020
*/


package com.trainingpractice.account.bankingapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.trainingpractice.account.bankingapplication.dataaccess.SBAccountDAO;
import com.trainingpractice.account.bankingapplication.model.SBAccount;
import com.trainingpractice.account.bankingapplication.service.SBAccountService;
/**
 *  @SpringBootTest annotation tells Spring Boot to look for a main configuration class which is BankingapplicationApplication and use that to start a Spring application context.
 */
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
/**
 * BankingapplicationApplicationTests is a class for performing JUnit testing
 */
class BankingapplicationApplicationTests {
	/**
	 *  @Mock creates a mock implementation for the class it is annotated with.SBAccountService have dependency to SBAccountDAO Repository, we create mock object to model behaviour of the real object.
	 */
	@Mock
	private SBAccountDAO sBAccountDAOMock;
	/**
	 * @InjectMocks creates the mock implementation and it also injects the dependent mocks that are marked with the annotations here Create Object of service class to inject mock dependency
	 */
	@InjectMocks
	private SBAccountService service;
	/**
	 * @Test denotes a test case
	 */
	@Test
	public void testGetAllAccountsByBalance() {
		SBAccount  sb1=new SBAccount();
		sb1.setBalance(40000);
		SBAccount  sb2=new SBAccount();
		sb2.setBalance(30000);
		SBAccount  sb3=new SBAccount();
		sb3.setBalance(20000);
		SBAccount  sb4=new SBAccount();
		sb4.setBalance(54000);
		List<SBAccount> accounts=new ArrayList<>();
		accounts.add(sb1);
		accounts.add(sb2);
		accounts.add(sb3);
		accounts.add(sb4);
		when(sBAccountDAOMock.getAllSBAccounts()).thenReturn(accounts);
		assertEquals(3,service.getAccountsBasedOnBalance(20000).size());
	}

}
