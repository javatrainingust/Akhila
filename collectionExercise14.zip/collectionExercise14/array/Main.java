package com.ust.collection.array;

import java.util.HashSet;

import java.util.Set;

public class Main {

	public static void main(String[] args) {

		boolean[] cat = new boolean[4];

		Set<Cat> cats = new HashSet<Cat>();

		cat[0] = cats.add(new Cat("Dora", 4));

		cat[1] = cats.add(new Cat("Snow", 1));

		cat[2] = cats.add(new Cat("Kitty", 2));

		cat[3] = cats.add(new Cat("Dora", 4));

		for (int i = 0; i < cat.length; i++) {

			System.out.println("Value inside cat boolean array:" + cat[i]);
		}

		for (Object s : cats) {

			System.out.println("Value inside cat Set:" + s);
		}

	}
}
