package com.ust.collection.hashset;

import java.util.HashSet;
import java.util.Set;

public class Test {

	public static void main(String[] args) {
		boolean[] a = new boolean[3];

		Set<String> test1 = new HashSet<String>();

		a[0] = test1.add("test");

		a[1] = test1.add("work");

		a[2] = test1.add("test");

		for (int i = 0; i < a.length; i++) {
			System.out.println("Value inside boolean array:" + a[i]);

		}
		for (Object object : test1) {
			System.out.println("Value inside Set:" + object);

		}

	}
}
