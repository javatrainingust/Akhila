package com.practice.lambdaexpression;


public interface NumCalculator {
	/* abstract method getValue takes 2 arguments */
	public int getValue(int a, int b);

}


