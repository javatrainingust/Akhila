package com.practice.lambdaexpression;

public class Main {

	public static void main(String[] args) {
		CheckValue isEven = (a) -> a % 2 == 0;
		if (isEven.check(8))
			System.out.println("8 is odd");

		/* Logic to add 2 numbers using lambda expression */
		NumCalculator addition = (int a, int b) -> (a + b);

		System.out.println("sum of a and b is = " + addition.getValue(5, 6));

		DisplayResult result = message -> System.out.println("Hello " + message);
		result.display("Akhila");

		Test test = () -> System.out.println("6*6=" + (6 * 6));
		test.test();

	}

}
