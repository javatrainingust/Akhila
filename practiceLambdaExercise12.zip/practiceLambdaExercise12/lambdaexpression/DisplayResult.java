package com.practice.lambdaexpression;

public interface DisplayResult {
	public void display(String s);

}
