package com.practice.lambdaexpression;

public interface CheckValue {
	public boolean check(int n);
	

}
