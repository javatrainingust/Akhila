package com.practice.lambdaexpression;

public interface Test {
	public void test();

}
