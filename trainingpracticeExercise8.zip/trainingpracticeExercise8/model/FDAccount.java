package com.trainingpractice.model;

import java.time.LocalDate;

import com.trainingpractice.calculation.ICalculator;
import com.trainingpractice.calculation.IntrestCalculation;


public class FDAccount extends Account implements Renewable{
	

    public int tenure=10;
    private boolean isAutoRenewal;
    private double principal;
	private int rate;
	private float interestRate;

	public int getTenure() {
		return tenure;
	}



	public void setTenure(int tenure) {
		this.tenure = tenure;
	}



	public boolean isAutoRenewal() {
		return isAutoRenewal;
	}



	public void setAutoRenewal(boolean isAutoRenewal) {
		this.isAutoRenewal = isAutoRenewal;
	}


	public double getPrincipal() {
		return principal;
	}



	public void setPrincipal(double principal) {
		this.principal = principal;
	}



	public int getRate() {
		return rate;
	}



	public void setRate(int rate) {
		this.rate = rate;
	}


	IntrestCalculation interest=new IntrestCalculation();
	
	

//	public void updateRenewal(String renewalStatus){
//		if(renewalStatus.equals("yes")){
//			this.autoRenewal=true;
//			System.out.println("renewal Status is "+autoRenewal);
//		}
//	}


	public void interestCalculation(float amount,ICalculator interest) {
		System.out.println("Inside FDAccount");
		float interestfd=interest.calculateInterest(amount);
		System.out.println("Interest for Fd is="+interestfd);
	}
@Override
public void autoRenewal(int tenure) {
	if(isAutoRenewal == true ) {
		
		if(tenure == 12) {
			System.out.println("please auto renew the account");
		}
		else if(tenure<12) 
		System.out.println("auto renew before renewel date ends");
		else {
			System.out.println("auto renewed");
		}
	}

}


}