package com.trainingpractice.model;

import com.trainingpractice.calculation.IntrestCalculation;

public class Account {
	private int accountNo;
	private String accountHolderName;
	private float balance=50000;
	
	
	
	public void withdrawMoney(float amountToWithdraw) {
		
		this.balance=this.balance-amountToWithdraw;
		System.out.println("Available balace="+this.balance);
		
	}
	public void caluculateInterest() {
		System.out.println("calculating interest");
	}


	public int getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}


	public String getAccountHolderName() {
		return accountHolderName;
	}


	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}


	public float getBalance() {
		return balance;
	}
	
        public void interestCalculation(float amount) {
	
	System.out.println("Inside Account class);
        }

        }
