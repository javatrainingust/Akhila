package com.trainingpractice.calculation;

public class IntrestCalculation {
float fdRate=0.3f;
float sbRate=0.7f;
float  duration=1;


	public float calculateInterest(float amount){
	float interestamountfd=(amount*fdRate*duration)/100 ;
	return interestamountfd;
	}
	public float calculateInterest(float amount,float duration){
		float sbinterestamount=(amount*sbRate*duration)/100 ;
		return sbinterestamount;
		}





} 