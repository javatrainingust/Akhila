/**
 * Singer
 * 
 *  Singer class for handling singer data
 * 
 * 12/10/2020
 * 
 */

package com.trainingpractice.spring.model;

import com.trainingpractice.spring.util.Performer;
/**
 * Singer class implements performer interface
 */
public class Singer implements Performer {
	public String song;
	
/**
 * Constructor of singer class 
 */
	public Singer(String song) {
		super();
		this.song = song;
	}

/**
 * Perform method to  print the song
 */
	public void perform() {
		System.out.println("The song is="+this.song);
		
		
	}
	

}
