/**
 *Saxophone
 * 
 * Saxophone class for Dependency injection using setter method
 * 
 * 12/10/2020
 */


package com.trainingpractice.spring.model;

import com.trainingpractice.spring.util.Instrument;
/**
 *Saxophone implements instrument interface
 */
public class Saxophone implements Instrument {
	

	public void play() {

		System.out.println("playing started by saxophone");
		
	}

}
