/**
 * Instrumentalist 
 * 
 *Instrumentalist  class  for dependency injection through setter method
 *
 *
 */
package com.trainingpractice.spring.model;

import com.trainingpractice.spring.util.Performer;
/**
 * Instrumentalist implements performer interface
 */
public class Instrumentalist implements Performer {

	Saxophone saxophon;
	
	/**
	 * get method
	 */
	public Saxophone getSaxophon() {
		return saxophon;
	}

	/**
	 * setter method for dependency injection
	 */
	public void setSaxophon(Saxophone saxophon) {
		this.saxophon = saxophon;
	}

	/**
	 * implementation of performer interface
	 */
	public void perform() {
		
		this.saxophon.play();
	}

}

