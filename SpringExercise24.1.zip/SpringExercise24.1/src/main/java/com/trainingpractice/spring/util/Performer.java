/**
 *Performer
 * 
 * Performer class is an interface
 * 
 * 12/10/2020
 * 
 */

package com.trainingpractice.spring.util;
/**
 *Consist of One method perform 
 */
public interface Performer {
	public void perform();

}
