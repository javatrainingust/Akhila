package com.trainingpractice.functional.stream;

import java.util.Arrays;
import java.util.stream.Stream;

public class StreamDemo2 {

	public static void main(String[] args) {

		// Creating a String array
		String[] arr = { "Vinoth", "Suresh", "Jane", "Roshan" };

		// Using Arrays.stream() to convert array into Stream
		Stream<String> stream = Arrays.stream(arr);

		// Displaying elements in Stream

		long numberOfElements = stream.count();
		System.out.println("Count of Elements of string in array:=" + numberOfElements);
	}

}
