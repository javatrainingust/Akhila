package com.trainingpractice.functional.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
		// creating an Arraylist objects
		List<String> string = new ArrayList<String>();
		string.add("Vinoth");
		string.add("Suresh");
		string.add("Jane");
		string.add("Roshan");
		Stream<String> stringStream = string.stream();
		// count no of elements
		long numberOfElements = stringStream.count();

		System.out.println("Count of elements: " + numberOfElements);

	}

}
