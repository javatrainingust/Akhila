/**
 * SpringDemo
 * 
 * This class is for Spring Inversion of control
 * 
 * 13/10/2020
 */

package com.trainingpractice.spring.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
/**
 * Spring IOC demo class 
 */
public class SpringDemo {
	@Autowired
	Organizer organizer;
	public static void main(String[] args) {
		/* loading the definitions from the given XML file */
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		Organizer org = context.getBean("competionOrganizer", Organizer.class);

		org.sayGreetings();
	}

}
