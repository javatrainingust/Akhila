
/**
 * Instrumentalist 
 * 
 *Instrumentalist  class  for dependency injection through setter method
 *
 *
 */
package com.trainingpractice.spring.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.trainingpractice.spring.util.Performer;
/**
 * Instrumentalist implements performer interface
 */
@Component("instrumentalistObj")
public class Instrumentalist implements Performer {
@Autowired
	Saxophone saxophon;
	
	/**
	 * get method
	 */
	public Saxophone getSaxophon() {
		return saxophon;
	}

	/**
	 * setter method for dependency injection
	 */
	public void setSaxophon(Saxophone saxophon) {
		this.saxophon = saxophon;
	}

	/**
	 * implementation of performer interface
	 */
	public void perform() {
		
		this.saxophon.play();
	}

}

