/**
 * SBAccountController
 * 
 * SBAccountController  @controller annotation is used to declare the class as a controller
 *
 * 15/10/20
 * 
*/

package com.trainingpractice.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.trainingpractice.account.model.CurrentAccount;
import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.model.SBAccount;
import com.trainingpractice.account.service.SBAccountService;

/**
 * SBAccountController @controller annotation is used to declare the class as a controller.we created service class object
 */
@Controller
public class SBAccountController {
	@Autowired
	private SBAccountService service;
	/**
	 * showSBAccountform method which returns addSBAccount jsp
	 */
@RequestMapping("/showSBAccountform")
	
	public String showSBAccountAccountForm(Model model) {
		
	SBAccount sBAccount = new SBAccount();
		
		model.addAttribute("key", sBAccount);
		return "addSBAccount";
		
		
	}
/**
 * addSBAccount to add a particular account
 */
	@RequestMapping("/addSBAccount")
	public String addSBAccount(@ModelAttribute("sBAccounts") SBAccount sBAccount) {
		
		
		service.addSBAccount(sBAccount);
		
		return "redirect:/sBAccounts";
		
		
	}
	/**
	 * updateSBAccount to update a particular account
	 */
	@RequestMapping("/updateSBAccount")
	public String updateSBAccount(@ModelAttribute("sBAccounts") SBAccount sBAccount) {
		
		
		service.updateSBAccount(sBAccount);
		
		return "redirect:/sBAccounts";
		
		
	}

	/**
	 * @Requestmapping annotation is used to map the class with the specified URL name.
	 *                 
	 * 
	 */
	@RequestMapping("/sBAccounts")
	/**
	 * getAllSBAccounts method which returns a sBAccountsList jsp page
	 */
	public String getAllSBAccounts(Model model) {
		System.out.println("inside getAllSBAccounts");
		List<SBAccount> sBAccount = service.getAllSBAccounts();
		model.addAttribute("sBAccounts", sBAccount);
		return "sBAccountsList";
	}
	/**
	 * getSBAccount is  a method to display particular account details .
	 */	
	@RequestMapping("/viewSBAccount")
	public String getSBAccount(@RequestParam("accNo") String accNo,Model model ) {
	
		SBAccount sBAccount=service.getSBAccountByAccountNo(Integer.parseInt(accNo));
	model.addAttribute("key",sBAccount);
	return "viewSBAccount";
	
}
	/**
	 * getAllSBAccountsSortByName to sort the accounts by name 
	 */
@RequestMapping("/sortSBAccountByName")
	
	public String getAllSBAccountsSortByName(Model model){
	System.out.println("Inside controller getAllSBAccountsSortByName");
		
		List<SBAccount> accountList = service.getAllSBAccountsSortedByAccountHolderName();
		
		model.addAttribute("sBAccounts",accountList );
		
		
		return "SBAccountsList";
		
	}
/**
 *getAllSBAccountSortByBalance sort accounts based on balance
 */
	@RequestMapping("/sortSBAccountsByBalance")	
	public String getAllSBAccountSortByBalance(Model model){
	System.out.println("Inside controller getAllSBAccountsSortByBalance");
		
		List<SBAccount> sBAccount = service.getAllSBAccountsSortedByBalance();
		
		model.addAttribute("sBAccounts",sBAccount);
		
		
		return "sBAccountsList";
		
	}
	/**
	 * deleteSBAccount is to delete a particular account
	 */
	@RequestMapping("/deleteSBAccount")
	public String deleteSBAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		service.deleteSBAccount(Integer.parseInt(accNo));
		
				
		return "redirect:/sBAccounts";
		
		
}
}
