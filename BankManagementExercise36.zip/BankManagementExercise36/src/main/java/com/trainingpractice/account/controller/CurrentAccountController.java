/**
 * CurrentAccountController
 * 
 * CurrentAccountController  @controller annotation is used to declare the class as a controller
 *
 * 15/10/20
 * 
*/

package com.trainingpractice.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.trainingpractice.account.model.CurrentAccount;
import com.trainingpractice.account.service.CurrentAccountService;
/**
 * CurrentAccountController @controller annotation is used to declare the class as a controller. we created service class object 
 */
@Controller
public class CurrentAccountController {
	@Autowired
	private CurrentAccountService service;
	/**
	 * showCurrentAccountform"method which returns addCurrentAccount jsp
	 */
@RequestMapping("/showCurrentAccountform")
	
	public String showAccountForm(Model model) {
		
	CurrentAccount currentAccount = new CurrentAccount();
		
		model.addAttribute("key", currentAccount);
		return "addCurrentAccount";
		
		
	}
/**
 * addCurrentAccount add a particular account
 */
	@RequestMapping("/addCurrentAccount")
	public String addCurrentAccount(@ModelAttribute("currentAccounts") CurrentAccount currentAccount) {
		
		
		service.addCurrentAccount(currentAccount);
		
		return "redirect:/accounts";
		
		
	}
	/**
	 * updateCurrentAccount to update a particular account
	 */
	
	@RequestMapping("/updateCurrentAccount")
	public String updateCurrentAccount(@ModelAttribute("currentAccounts") CurrentAccount currentAccount) {
		
		
		service.updateCurrentAccount(currentAccount);
		
		return "redirect:/accounts";
		
		
		
	}
	
	/**
	 * @Requestmapping annotation is used to map the class with the specified URL name.
	 */
	@RequestMapping("/accounts")

	/**
	 * getAllCurrentAccounts method which returns a currentAccountList jsp page
	 */
	public String getAllCurrentAccounts(Model model) {
		System.out.println("inside getAllCurrentAccounts");
		List<CurrentAccount> currentaccount=service.getAllCurrentAccounts();
		model.addAttribute("accounts",currentaccount);
		return "currentAccountList";
	}
	/**
	 * getCurrentAccount is  a method to display particular account details .
	 */	

		@RequestMapping("/viewCurrentAccount")
		public String getCurrentAccount(@RequestParam("accNo")String accNo,Model model) {
			
			
			CurrentAccount currentAccount = service.getCurrentAccountByAccountNo(Integer.parseInt(accNo));
			
			model.addAttribute("key", currentAccount);
			
			
			return "viewCurrentAccount";
		
		
}
		/**
		 * sortCurrentAccountByName to sort the accounts by name 
		 */
		@RequestMapping("/sortCurrentAccountByName")
		
		public String getAllCurrentAccountsSortByName(Model model){
		System.out.println("Inside controller getAllCurrentAccountsSortByName");
			
			List<CurrentAccount> currentaccount = service.getAllCurrentAccountsSortedByAccountHolderName();
			
			model.addAttribute("accounts",currentaccount );
			
			
			return "currentAccountList";
			
		}
		/**
		 * getAllCurrentAccountsSortByOverDraftLimit to sort the accounts 
		 */
		@RequestMapping("/sortCurrentAccountsByOverDraftLimit")	
		public String getAllCurrentAccountsSortByOverDraftLimit(Model model){
		System.out.println("Inside controller getAllAccountsSortByOverDraftLimit");
			
			List<CurrentAccount> currentaccountsList = service.getAllCurrentAccountsSortedByOverDraftLimit();
			
			model.addAttribute("accounts",currentaccountsList);
			
			
			
			return "currentAccountList";
			
		}
		/**
		 * deleteCurrentAccount is to delete a particular account
		 */
		@RequestMapping("/deleteCurrentAccount")
		public String deleteCurrentAccount(@RequestParam("accNo")String accNo,Model model) {
			
			
			service.deleteCurrentAccount(Integer.parseInt(accNo));
			
					
			return "redirect:/accounts";
			
			
		}
}
