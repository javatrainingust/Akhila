/**
 * LoanAccountDAOImpl
 * LoanAccountDAOImpl is an implementation class for LoanAccountDAO
 * 10/6/2020
*/


package com.trainingpractice.account.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.trainingpractice.account.model.LoanAccount;
/**
* Class contains methods for performing getAll ,add ,delete  the current accounts.
*/
public class LoanAccountDAOImpl implements LoanAccountDAO {

	/**
	*Constructor of LoanAccountDAOImpl
	*/
	List<LoanAccount> loanAccountList;
	private Set loanAccountSet;
	public LoanAccountDAOImpl() {
		loanAccountList = new ArrayList<LoanAccount>();
		loanAccountSet= new HashSet<LoanAccount>();
		
		LoanAccount la1 = new LoanAccount(1000, "Akhila", 2000,2300);
		LoanAccount la2 = new LoanAccount(1001, "Sonu", 1000,1500);
		LoanAccount la3 = new LoanAccount(1002, "Arun", 1500,2000);
		LoanAccount la4 = new LoanAccount(1003, "Anu", 4000,3000);
		loanAccountList.add(la1);
		loanAccountList.add(la2);
		loanAccountList.add(la3);
		loanAccountList.add(la4);
		 

	}
	/* getAllLoanAccounts method is for getting all the LoanAccount*/

	
	public List<LoanAccount> getAllLoanAccounts() {
		return loanAccountList;
	}
	/* getLoanAccountByAccountNo method is for getting the particular  LoanAccount*/

	
	public LoanAccount getLoanAccountByAccountNo(int accountNo) {
		LoanAccount loanAccount = null;
		Iterator<LoanAccount> iterator = loanAccountList.iterator();
		while (iterator.hasNext()) {
			LoanAccount loanAccount2 = (LoanAccount) iterator.next();
			if (loanAccount2.getAccountNo() == accountNo) {
				loanAccount = loanAccount2;

			}

		}
		return loanAccount;
	}
	/* deleteLoanAccount method is for deleting a particular  LoanAccount*/

	
	public void deleteLoanAccount(int accountNo) {
		// TODO Auto-generated method stub
		LoanAccount loanAccount = null;
		for (int i = 0; i < loanAccountList.size(); i++) {
			loanAccount = (LoanAccount) loanAccountList.get(i);
			if (loanAccount.getAccountNo() == accountNo) {
				loanAccountList.remove(i);
			}

		}
	}

	
	public boolean addLoanAccount(LoanAccount loanAccount) {
		boolean  isAdded=loanAccountSet.add(loanAccount);
		if(isAdded) {
			loanAccountList.add(loanAccount);
		}
		return isAdded;
	}

	
	public void updateLoanAccount(LoanAccount loanAccount) {
		Iterator<LoanAccount> iterator=loanAccountList.iterator();
		while (iterator.hasNext()) {
			LoanAccount la = (LoanAccount) iterator.next();
			if(la.getAccountNo()==loanAccount.getAccountNo()) {
				la.setAccountHolderName(loanAccount.getAccountHolderName());
				la.setAccountNo(loanAccount.getAccountNo());
				//la.setBalance(loanAccount.getBalance());
				la.setLoanOutStanding(loanAccount.getLoanOutStanding());
		
	}
}
	}}
