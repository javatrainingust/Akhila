package com.trainingpractice.account.dataaccess;

import java.util.List;

import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.model.SBAccount;
/**
 * SBAccountDAO 
 * SBAccountDAO is an interface which contains the methods for implementation class
 * 10/6/2020
*/
public interface SBAccountDAO {
	public List<SBAccount> getAllSBAccounts();

	public SBAccount getSBAccountByAccountNo(int accountNo);

	public void deleteSBAccount(int accountNo);
	public boolean addSBAccount(SBAccount sBAccount);
	public void updateSBAccount(SBAccount sBAccount);
}
