/**
 *  InsufficientBalanceException
 * 
 *  InsufficientBalanceException class consist of private variables interestCalculation method
 *
 * 10/9/2020
 * 
*/

package com.trainingpractice.account.model;

/**
 * This class extends to Exception
 */

public class InsufficientBalanceException extends Exception {

	float balance;

	public InsufficientBalanceException(float balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "InsufficientBalanceException [balance=" + balance + "]";
	}
	}


