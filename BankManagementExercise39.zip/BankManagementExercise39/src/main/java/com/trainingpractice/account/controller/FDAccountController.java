/**
 * FDAccountController
 * 
 * FDAccountController  @controller annotation is used to declare the class as a controller
 *
 * 15/10/20
 * 
*/

package com.trainingpractice.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.trainingpractice.account.model.CurrentAccount;
import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.service.FDAccountService;
/**
 * FDAccountController @controller annotation is used to declare the class as a controller.we created service class object 
 */
@Controller
public class FDAccountController {
	@Autowired
	private FDAccountService service;
	/**
	 * showFDAccountForm method which returns addFDAccount jsp
	 */
@RequestMapping("/showFDAccountform")
	
	public String showFDAccountForm(Model model) {
		
	FDAccount fDAccount = new FDAccount();
		
		model.addAttribute("key", fDAccount);
		return "addFDAccount";
		
		
	}
/**
 * addFDAccount add a particular account
 */
	@RequestMapping("/addFDAccount")
	public String addFDAccount(@ModelAttribute("fDAccounts") FDAccount fDAccount) {
		
		
		service.addFDAccount(fDAccount);
		
		return "redirect:/fDAccounts";
		
		
	}
	/**
	 * updateFDAccount to update a particular account
	 */
	@RequestMapping("/updateFDAccount")
	public String updateFDAccount(@ModelAttribute("fDAccounts") FDAccount fDAccount) {
		
		
		service.updateFDAccount(fDAccount);
		
		return "redirect:/fDAccounts";
		
		
	}
	
	/**
	 * @Requestmapping annotation is used to map the class with the specified URL name.
	 */
	@RequestMapping("/fDAccounts")
	/**
	 * getAllFDAccounts method which returns a fDAccountList jsp page
	 */
	public String getAllFDAccounts(Model model) {
		System.out.println("inside getAllFDAccounts");
		List<FDAccount> accountList=service.getAllFDAccounts();
		model.addAttribute("fDAccounts",accountList);
		return "fDAccountList";
}
	/**
	 * getAllFDAccountsSortByName sort based on name
	 */
	
@RequestMapping("/sortFDAccountByName")
	
	public String getAllFDAccountsSortByName(Model model){
	System.out.println("Inside controller getAllFDAccountsSortByName");
		
		List<FDAccount> accountList = service.getAllFDAccountsSortedByAccountHolderName();
		
		model.addAttribute("fDAccounts",accountList );
		
		
		return "fDAccountList";
		
	}
/**
 * getAllFDAccountsSortByBalance sort based on balance
 */
	@RequestMapping("/sortFDAccountsByBalance")	
	public String getAllFDAccountsSortByBalance(Model model){
	System.out.println("Inside controller getAllAccountsSortByBalance");
		
		List<FDAccount> fDAccountsList = service.getAllFDAccountsSortedByBalance();
		
		model.addAttribute("fDAccounts",fDAccountsList);
		
		
		return "fDAccountList";
		
	}
	/**
	 * getFDAccount is  a method to display particular account details .
	 */	
	@RequestMapping("/viewFDAccount")
	public String getFDAccount(@RequestParam("accNo") String accNo,Model model ) {
	
		FDAccount fDAccount=service.getFDAccountByAccountNo(Integer.parseInt(accNo));
	model.addAttribute("key", fDAccount);
	return "viewFDAccount";
	
		
		
}
	/**
	 * deleteFDAccount is to delete a particular account
	 */
	@RequestMapping("/deleteFDAccount")
	public String deleteFDAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		service.deleteFDAccount(Integer.parseInt(accNo));
		
				
		return "redirect:/fDAccounts";
		
		
	}
}