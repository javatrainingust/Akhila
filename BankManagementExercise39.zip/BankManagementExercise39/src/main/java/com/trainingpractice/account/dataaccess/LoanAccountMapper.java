/**
 *  LoanAccountMapper
 * 
 *  LoanAccountMapper implements RowMapper
 *
 * 23/10/20
 * 
*/
package com.trainingpractice.account.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.trainingpractice.account.model.LoanAccount;
/**
 *  LoanAccountMapper implements RowMapper
*/

	public class  LoanAccountMapper implements RowMapper<LoanAccount> {

		public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
			LoanAccount loanAccount=new LoanAccount();
			loanAccount.setAccountNo(rs.getInt("accountNo"));
			loanAccount.setAccountHolderName(rs.getString("accountHolderName"));
			loanAccount.setBalance(rs.getFloat("balance"));
			loanAccount.setLoanOutStanding(rs.getFloat("loanOutStanding"));
			return loanAccount;
		}
}
