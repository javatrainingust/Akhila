/**
 *  SBAccountMapper
 * 
 *  SBAccountMapper implements RowMapper
 *
 * 23/10/20
 * 
*/
package com.trainingpractice.account.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.trainingpractice.account.model.SBAccount;
/**
 *  SBAccountMapper implements RowMapper
*/
public class SBAccountMapper implements RowMapper<SBAccount> {

	public SBAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		SBAccount sBAccount=new SBAccount();
		sBAccount.setAccountNo(rs.getInt("accountNo"));
		sBAccount.setAccountHolderName(rs.getString("accountHolderName"));
		sBAccount.setBalance(rs.getFloat("balance"));
		return sBAccount;
	}
	

}
