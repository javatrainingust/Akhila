/**
 * SBAccountDAOSQLImpl
 * 
 * SBAccountDAOSQLImpl implements SBAccountDAO
 *
 * 23/10/20
 * 
*/
package com.trainingpractice.account.dataaccess;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trainingpractice.account.model.SBAccount;
/**
 * SBAccountDAOSQLImpl implements SBAccountDAO
 * @Repository annotation is used to indicate that the class provides the mechanism for storage, retrieval, search, update and delete operation on objects.
 */
@Repository
public class SBAccountDAOSQLImpl implements SBAccountDAO {
	private DataSource dataSource;
private JdbcTemplate jdbcTemplateObject;
/**
 * @Autowired annotation can be used to autowire bean on the setter method 
 */
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	/**
	 * Method to get all SB accounts
	 */
	public List<SBAccount> getAllSBAccounts() {
		String SQL = "select * from account";
	      List <SBAccount> account= jdbcTemplateObject.query(SQL, new SBAccountMapper());
		
		return account;
	}
	/**
	 * Method to get  SB account by entering a particular accountNo
	 */
	public SBAccount getSBAccountByAccountNo(int accountNo) {
		String sql = "select*from account where accountNo = ?";
		 
		SBAccount account = (SBAccount) jdbcTemplateObject.queryForObject(
                sql, new Object[] { accountNo }, new SBAccountMapper());
      
       return 	account;
	}
	/**
	 * Method to delete SB account by entering a particular accountNo
	 */
	public void deleteSBAccount(int accountNo) {
		String query="delete from account where accountNo='"+accountNo+"' ";  
		 jdbcTemplateObject.update(query);  

		
	}
	/**
	 * Method to add  SB account 
	 */
	public boolean addSBAccount(SBAccount sBAccount) {
		String sql = "INSERT INTO ACCOUNT" +
	            "(ACCOUNTNO,ACCOUNTHOLDERNAME,BALANCE) VALUES (?, ?, ?)";
	  
	        
	  
		jdbcTemplateObject.update(sql, new Object[] {sBAccount.getAccountNo(),sBAccount.getAccountHolderName(),sBAccount.getBalance()});
		return true;
	}
	/**
	 * Method to update  SB account by entering a particular accountNo
	 */
	public void updateSBAccount(SBAccount sBAccount) {
			String query="update account  set  accountNo='"+sBAccount.getAccountNo()+"',accountHolderName='"+sBAccount.getAccountHolderName()+"' where balance='"+sBAccount.getBalance()+"' ";  
		    jdbcTemplateObject.update(query);  
		
	}

}
