/**
 * LoanAccountController
 * 
 * LoanAccountController  @Restcontroller annotation is used to declare the class as a controller
 *
 * 22/10/20
 * 
*/

package com.trainingpractice.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trainingpractice.account.model.LoanAccount;
import com.trainingpractice.account.service.LoanAccountService;

/**
 *@RestController is a specialized version of the controller. It includes the @Controller and @ResponseBody annotations and as a result, simplifies the controller implementation
*/
@RestController
public class LoanAccountController {
	@Autowired
	private LoanAccountService service;
	/**
	 * showLoanAccountform method which returns addLoanAccount jsp
	 */
@RequestMapping("/showLoanAccountform")
	
	public String showLoanAccountAccountForm(Model model) {
		
	LoanAccount loanAccount = new LoanAccount();
		
		model.addAttribute("key", loanAccount);
		return "addLoanAccount";
		
		
	}
/**
 * addSBAccount to add a particular Loan account
 */
	@RequestMapping(value="/loanAccounts",method=RequestMethod.POST)
	public LoanAccount addLoanAccount(@RequestBody LoanAccount loanAccount) {
		
		
		service.addLoanAccount(loanAccount);
		
		
		return loanAccount;
		
	}
	/**
	 * updateLoanAccount to update a particular Loan account
	 */
	@RequestMapping(value="/loanAccounts/{accNo}",method=RequestMethod.PUT)
	public LoanAccount updateLoanAccount(@PathVariable int accNo ,@RequestBody LoanAccount loanAccount) {
		
		LoanAccount oldLA=service.getLoanAccountByAccountNo(accNo);
		if (oldLA!=null) {
			service.updateLoanAccount(loanAccount);
		}
		
		
		return loanAccount;
		
		
	}
	/**
	 * addAccount to get all Loan account
	 */
	
	@RequestMapping(value="/loanAccounts",method=RequestMethod.GET)

	
	public List<LoanAccount> getAllLoanAccounts() {
		
		List<LoanAccount> loanAccountList = service.getAllLoanAccounts();
		
		return loanAccountList;
	}
	/**
	 * get account by entering a particular accNo
	 */
	@RequestMapping(value="/loanAccounts/{accNo}",method=RequestMethod.GET)
	public LoanAccount getLoanAccount(@PathVariable int accNo) {
		LoanAccount loanAccount=service.getLoanAccountByAccountNo(accNo);
		return loanAccount;
	}
	/**
	 * getLoanAccount is  a method to display particular account details .
	 */	
	@RequestMapping("/viewLoanAccount")
	public String getLoanAccount(@RequestParam("accNo") String accNo,Model model ) {
	
		LoanAccount loanAccount=service.getLoanAccountByAccountNo(Integer.parseInt(accNo));
	model.addAttribute("key",loanAccount);
	return "viewLoanAccount";
	
}
	/**
	 *getAllLoanAccountsSortByName sort based on name 
	 */
@RequestMapping("/sortLoanAccountByName")
	
	public String getAllLoanAccountsSortByName(Model model){
	System.out.println("Inside controller getAllLoanAccountsSortByName");
		
		List<LoanAccount> accountList = service.getAllLoanAccountsSortedByAccountHolderName();
		
		model.addAttribute("loanAccounts",accountList );
		
		
		return "loanAccountList";
		
	}
/**
 * getAllLoanAccountsSortByLoanOutStanding to sort account based on LoanOutStanding
 */
	@RequestMapping("/sortLoanAccountsByLoanOutStanding")	
	public String getAllLoanAccountsSortByLoanOutStanding(Model model){
	System.out.println("Inside controller getAllAccountsSortByLoanOutStanding");
		
		List<LoanAccount> loanAccount = service.getAllLoanAccountsSortedByLoanOutStanding();
		
		model.addAttribute("loanAccounts",loanAccount);
		
		
		return "loanAccountList";
		
	}
	/**
	 * deleteLoanAccount is to delete a particular account
	 */
	
	@RequestMapping(value="/loanAccounts/{accNo}",method=RequestMethod.DELETE)
	public void deleteLoanAccount(@PathVariable int accNo) {
		
		
		service.deleteLoanAccount(accNo);
		
	}
}
