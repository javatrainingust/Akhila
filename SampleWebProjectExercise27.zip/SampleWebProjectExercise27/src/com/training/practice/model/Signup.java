/**
 * Signup
 * Signup class is the model class for Signing up by entering details .
 * 14/10/20
 * */



package com.training.practice.model;
/**
 * Signup class is the model class which contains following fields.
 */
public class Signup {
	private String UserName;
	private String userId;

	private String password;
	private String confirmPassowrd;
	
	/**
	 * getter for Username
	 * */
	public String getUserName() {
		return UserName;
	}
	/**
	 * setter for Username
	 * */
	public void setUserName(String userName) {
		UserName = userName;
	}
	/**
	 * getter for UserId
	 * */
	public String getUserId() {
		return userId;
	}
	/**
	 * setter for UserId
	 * */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * getter for password
	 * */
	public String getPassword() {
		return password;
	}
	/**
	 * setter for password
	 * */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * getter for ConfirmPassword
	 * */
	public String getConfirmPassowrd() {
		return confirmPassowrd;
	}
	/**
	 * setter for ConfirmPassword
	 * */
	public void setConfirmPassowrd(String confirmPassowrd) {
		this.confirmPassowrd = confirmPassowrd;
	}


}
