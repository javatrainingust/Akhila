package com.trainingpractice.model;

import com.trainingpractice.calculation.ICalculator;
import com.trainingpractice.calculation.IntrestCalculation;

public class SBAccount extends Account {

    public float balance=400000;
	IntrestCalculation interest=new IntrestCalculation();
	private int rate;
	private float interestRate;
	private int principal;
	private float duration;
	public SBAccount() {
		System.out.println("Inside SB account no arg constructor");
	}
	
	public SBAccount(float balance, float duration) {
		super();
		this.balance = balance;
		this.duration = duration;
		System.out.println("parameterized constructor of sb account");
	}


	public float getbalance() {
          return balance;
    }
    
    public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getPrincipal() {
		return principal;
	}

	public void setPrincipal(int principal) {
		this.principal = principal;
	}

	public void withdrawMoney(float amountWithdrawn)
    {
          balance=balance- amountWithdrawn;
          System.out.println("Account balance after withdrawing is :" +balance);
    }

//    @Override
//    public void caluculateInterest() {
//    	
//    	interestRate=(principal*rate*1)/100;
//    	System.out.println("The simple interest rate for SBAccount is="+interestRate);
//    }
	
	public void interestCalculation(float amount,float duration,ICalculator interest) {
		float interestsb=interest.calculateInterest(amount,duration);
		System.out.println("The interest for SB="+interestsb);
	}
}




