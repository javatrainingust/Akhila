package com.trainingpractice.model;

public class LoanAccount extends Account{
	private float EMI;
	private float loanOutStanding;
	private int tenure;
	
	public LoanAccount() {
		
		System.out.println("Inside loan account no arg constructor");
	}
	
	
	public LoanAccount(int tenure) {
		super();
		this.tenure = tenure;
		System.out.println("inside parameterized constructor of loan account");
	}


	

	public float getEMI() {
		return EMI;
	}
	public void setEMI(float eMI) {
		EMI = eMI;
	}
	public float getLoanOutStanding() {
		return loanOutStanding;
	}
	public void setLoanOutStanding(float loanOutStanding) {
		this.loanOutStanding = loanOutStanding;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public void calculateEMI() {
		
		EMI=loanOutStanding*3*tenure;
		System.out.println("EMI for this Account is="+EMI);
	}

}


