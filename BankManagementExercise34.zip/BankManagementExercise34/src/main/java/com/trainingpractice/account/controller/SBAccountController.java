/**
 * SBAccountController
 * 
 * SBAccountController  @controller annotation is used to declare the class as a controller
 *
 * 15/10/20
 * 
*/

package com.trainingpractice.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.trainingpractice.account.model.CurrentAccount;
import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.model.SBAccount;
import com.trainingpractice.account.service.SBAccountService;

/**
 * SBAccountController @controller annotation is used to declare the class as a controller.we created service class object
 */
@Controller
public class SBAccountController {
	@Autowired
	private SBAccountService service;
	/**
	 * showSBAccountform method which returns addSBAccount jsp
	 */
@RequestMapping("/showSBAccountform")
	
	public String showSBAccountAccountForm(Model model) {
		
	SBAccount sBAccount = new SBAccount();
		
		model.addAttribute("key", sBAccount);
		return "addSBAccount";
		
		
	}
/**
 * addSBAccount to add a particular account
 */
	@RequestMapping("/addSBAccount")
	public String addSBAccount(@ModelAttribute("sBAccounts") SBAccount sBAccount) {
		
		
		service.addSBAccount(sBAccount);
		
		return "redirect:/sBAccounts";
		
		
	}

	/**
	 * @Requestmapping annotation is used to map the class with the specified URL name.
	 *                 
	 * 
	 */
	@RequestMapping("/sBAccounts")
	/**
	 * getAllSBAccounts method which returns a sBAccountsList jsp page
	 */
	public String getAllSBAccounts(Model model) {
		System.out.println("inside getAllSBAccounts");
		List<SBAccount> sBAccountsList = service.getAllSBAccounts();
		model.addAttribute("sBAccounts", sBAccountsList);
		return "sBAccountsList";
	}
	/**
	 * getSBAccount is  a method to display particular account details .
	 */	
	@RequestMapping("/viewSBAccount")
	public String getSBAccount(@RequestParam("accNo") String accNo,Model model ) {
	
		SBAccount sBaccount=service.getSBAccountByAccountNo(Integer.parseInt(accNo));
	model.addAttribute("key",sBaccount);
	return "viewSBAccount";
	
}
	/**
	 * deleteSBAccount is to delete a particular account
	 */
	@RequestMapping("/deleteSBAccount")
	public String deleteSBAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		service.deleteSBAccount(Integer.parseInt(accNo));
		
				
		return "redirect:/sBAccounts";
		
		
}
}
