package com.trainingpractice.bankaccount.service;

import com.trainingpractice.model.FDAccount;
import com.trainingpractice.model.SBAccount;

public class InterestService {
	public static void main(String[] args) {
		FDAccount fDAccount=new FDAccount();
		fDAccount.setAccountHolderName("Anjali");
		fDAccount.setAccountNo(6325);
		fDAccount.setPrincipal(1200);
		fDAccount.setRate(7);
		System.out.println("Account holder name is ="+fDAccount.getAccountHolderName());
		System.out.println("Account no is ="+fDAccount.getAccountNo());
		 fDAccount.caluculateInterest();
	
	SBAccount sBAccount=new SBAccount();
	sBAccount.setAccountHolderName("Anju");
	sBAccount.setAccountNo(3232);
	sBAccount.setPrincipal(3000);
	sBAccount.setRate(5);
	System.out.println("Account holder name is ="+sBAccount.getAccountHolderName());
	System.out.println("Account no is ="+sBAccount.getAccountNo());
	sBAccount.caluculateInterest();
}
}
