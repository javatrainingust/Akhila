package com.trainingpractice.model;

public interface Renewable {
	public  void autoRenewal(int tenure); 

}

