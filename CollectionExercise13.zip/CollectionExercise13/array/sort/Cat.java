package com.ust.collection.array.sort;

public class Cat implements Comparable<Cat> {
	private String name;
	private Integer age;

	/* no argument constructor */
	public Cat() {

	}

	/* parameterized constructor */
	public Cat(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Cat [name=" + name + ", age=" + age + "]";
	}

	/* method for comparing cat age */
	@Override
	public int compareTo(Cat c) {

		return age.compareTo(c.age);
	}

}
