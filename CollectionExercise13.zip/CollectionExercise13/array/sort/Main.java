package com.ust.collection.array.sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		List<Cat> cats = new ArrayList<Cat>();
		cats.add(new Cat("Dora", 4));
		cats.add(new Cat("Snow", 1));
		cats.add(new Cat("Kitty", 2));
		System.out.println("Before sorting");
		Iterator<Cat> catiterator = cats.iterator();
		while (catiterator.hasNext()) {

			Cat cat = catiterator.next();

			System.out.println(cat);
		}
		System.out.println();
		System.out.println("Cats sorted by age");
		Collections.sort(cats);
		Iterator<Cat> catiterator1 = cats.iterator();
		while (catiterator1.hasNext()) {

			Cat cat = catiterator1.next();
			System.out.println(cat);
		}

	}
}
