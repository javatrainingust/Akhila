package com.ust.collection.arraylist;

import java.util.ArrayList;
import java.util.Collections;

public class ListMain {

	public static void main(String[] args) {
		ArrayList<String> students=new ArrayList<String>();
		students.add("Vivek");
		students.add("Vijay");
		students.add("Ajith");
		students.add("Surya");
		System.out.println("Before sorting arraylist of students");
		//iterating ArrayList
		for (String string : students) {
			System.out.println(string);
			
		}
		System.out.println();
		System.out.println("After sorting the arraylist of students");
		System.out.println();
		Collections.sort(students);
		
		for (int i = 0; i< students.size(); i++) {
			
			System.out.println(students.get(i));
		}
		

	}

}
