/**
 * FDAccountServiceTest
 * FDAccountServiceTest  is for performing JUnit test 
 * 10/6/2020
*/

package com.trainingpractice.account.service;



import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.trainingpractice.account.dataaccess.FDAccountDAOImpl;
import com.trainingpractice.account.model.CurrentAccount;
import com.trainingpractice.account.model.FDAccount;

/**
 * This class Contains various test cases
 */
class FDAccountServiceTest {
	FDAccountService fDAccountService;

	/**
	 * Constructor for LoanAccountServiceTest
	 */
	public FDAccountServiceTest() {
		fDAccountService = new FDAccountService();
		fDAccountService.addFDAccount(new FDAccount(1000, "Akhila", 1000));
		fDAccountService.addFDAccount(new FDAccount(1001, "Anjali", 10000));
	}

	/**
	 * Test Method to add account successfully
	 */
	@Test
	void testAddCurrentAccountSuccess() {
		int expectedValue =7 ;

		fDAccountService.addFDAccount(new FDAccount(1005, "Anagha", 60000));
		List<FDAccount> actualValue = fDAccountService.getAllFDAccounts();
		assertEquals(expectedValue, actualValue.size());

	}

	/**
	 * Test Method if there is failure to add account
	 */
	@Test
	public void testAddCurrentAccountFailure() {
		String expected = "Akhila";
		fDAccountService.addFDAccount(new FDAccount(1000, "Anjali", 1000));
		String actual = fDAccountService.getFDAccountByAccountNo(1000).getAccountHolderName();
		assertEquals(expected, actual);

	}

	/**
	 * Test method to update account
	 */
	@Test
	public void testUpdateFDAccount() {

		fDAccountService.updateFDAccount(new FDAccount(1001, "Anjali", 50000));
		float actual = fDAccountService.getFDAccountByAccountNo(1001).getBalance();
		float expected = 50000;
		assertEquals(expected, actual);

	}

	/**
	 * This test case is for testing whether expected and actual values are same
	 */
	@Test
	void testGetAllFDAccountsSortedByAccountHolderName() {
		String expected = "Akhila";
		
		FDAccount actual = fDAccountService.getAllFDAccountsSortedByAccountHolderName().get(0);
		assertEquals(expected, actual.getAccountHolderName());
	}

	/**
	 * This test case is for testing whether expected and actual values are same
	 */
	@Test
	void testGetAllFDAccountsSortedByBalance() {
		String expected = "Arun";
		
		FDAccount actual = fDAccountService.getAllFDAccountsSortedByBalance().get(1);
		assertEquals(expected, actual.getAccountHolderName());
	}

}



	/*
	 * List<FDAccount> expectedList;
	 * 
	 * public FDAccountServiceTest() {
	 * 
	 * expectedList = new ArrayList<FDAccount>(); FDAccount fd1 = new
	 * FDAccount(1000, "Akhila", 20000); FDAccount fd2 = new FDAccount(1001,
	 * "Anjali", 10000); FDAccount fd3 = new FDAccount(1002, "Arun", 15000);
	 * FDAccount fd4 = new FDAccount(1003, "Anu", 8000); expectedList.add(fd1);
	 * expectedList.add(fd2); expectedList.add(fd3); expectedList.add(fd4);
	 * 
	 * }
	 * 
	 *//**
		 * This test case is for testing whether expected and actual values are same
		 */
	/*
	 * @Test void testGetAllFDAccounts() { FDAccountDAOImpl fDAccountDAOImpl = new
	 * FDAccountDAOImpl();
	 * 
	 * List<FDAccount> actualList = fDAccountDAOImpl.getAllFDAccounts();
	 * 
	 * assertEquals(expectedList.size(), actualList.size()); }
	 * 
	 *//**
		 * This test case is for testing whether expected and actual values are same
		 */
	/*
	 * @Test void testGetFDAccountByAccountNo() { String expectedValue = "Anu";
	 * 
	 * FDAccountDAOImpl fDAccountDAOImpl = new FDAccountDAOImpl();
	 * 
	 * FDAccount actualValue = fDAccountDAOImpl.getFDAccountByAccountNo(1003);
	 * 
	 * assertEquals(expectedValue, actualValue.getAccountHolderName()); }
	 * 
	 *//**
		 * This test case is for testing whether expected and actual values are same
		 *//*
			 * @Test void testDeleteFDAccount() { FDAccountDAOImpl fDAccountDAOImpl = new
			 * FDAccountDAOImpl();
			 * 
			 * fDAccountDAOImpl.deleteFDAccount(1002);
			 * 
			 * List<FDAccount> actualValue = fDAccountDAOImpl.getAllFDAccounts();
			 * 
			 * assertEquals(expectedList.size() - 1, actualValue.size()); }
			 */
