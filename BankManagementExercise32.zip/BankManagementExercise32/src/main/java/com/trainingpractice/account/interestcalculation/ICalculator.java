package com.trainingpractice.account.interestcalculation;

/**...
 * 
 * ICalculator
 *providing  methods for implementing in classes that implements IntrestCalculation
 * 30/9/2020
 */

public interface ICalculator {

	public float calculateInterest(float amount);

	public float calculateInterest(float amount, float duration);

}
