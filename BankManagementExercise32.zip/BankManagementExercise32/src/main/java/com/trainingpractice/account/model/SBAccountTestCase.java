package com.trainingpractice.account.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

class SBAccountTestCase {

	@Test
	void testWithdrawMoneyFloat() {
		float expectedValue=30000;
		SBAccount acc=new SBAccount();
		
		
			try {
				acc.withdrawMoney(20000);
			} catch (InsufficientBalanceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		float actualValue=acc.getBalance();
		assertEquals(expectedValue, actualValue);
	}
	
}
