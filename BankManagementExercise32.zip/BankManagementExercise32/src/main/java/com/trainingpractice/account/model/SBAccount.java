/**
 * SBAccount 
 * 
 * CSBAccount  extends to Account class it consist of withdrawMoney method and interestCalculation method
 *
 * 30/9/2020
 * 
*/

package com.trainingpractice.account.model;

import com.trainingpractice.account.interestcalculation.ICalculator;
import com.trainingpractice.account.interestcalculation.IntrestCalculation;

public class SBAccount extends Account implements Comparable<SBAccount> {

	IntrestCalculation interest = new IntrestCalculation();
	private int rate;

	private int principal;
	private float duration;

	public SBAccount() {
		System.out.println("Inside SB account no arg constructor");
	}

	public SBAccount(int accountNo, String accountHolderName, float balance) {
		super(accountNo, accountHolderName, balance);

		System.out.println("parameterized constructor of sb account");
	}

	public float getDuration() {
		return duration;
	}

	public void setDuration(float duration) {
		this.duration = duration;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getPrincipal() {
		return principal;
	}

	public void setPrincipal(int principal) {
		this.principal = principal;
	}
	/* withdrawMoney method to know the withdrawal amount from bank  which throws exception when amountWithdrawn is more than balance*/

	public void withdrawMoney(float amountWithdrawn) throws InsufficientBalanceException {
		if (amountWithdrawn > this.balance) {
			throw new InsufficientBalanceException(amountWithdrawn);
		} else {
			this.balance = this.balance - amountWithdrawn;
			System.out.println("Available balance =" + this.balance);
		}

	}

	@Override
//    public void caluculateInterest() {
//    	
//    	interestRate=(principal*rate*1)/100;
//    	System.out.println("The simple interest rate for SBAccount is="+interestRate);
//    }
	/* interestCalculation method takes 2 arguments */
	public void interestCalculation(float amount, ICalculator interest) {
		float interestsb = interest.calculateInterest(amount, duration);
		System.out.println("The interest for SB=" + interestsb);
	}

	
	public int compareTo(SBAccount o) {

		return this.accountHolderName.compareTo(o.getAccountHolderName());
	}
}


