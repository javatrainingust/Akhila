package com.trainingpractice.account.dataaccess;



import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.trainingpractice.account.model.SBAccount;
/**
 * SBAccountDAOImplTest
 * SBAccountDAOImplTest is a class for performing JUnit testing
 * 10/6/2020
*/
public class SBAccountDAOImplTest {

	List<SBAccount> expectedList;

	public SBAccountDAOImplTest()

	{
		expectedList = new ArrayList<SBAccount>();
		SBAccount sb1 = new SBAccount(1000, "akhila", 2000);
		SBAccount sb2 = new SBAccount(1001, "Anjali", 1000);
		SBAccount sb3 = new SBAccount(1002, "Arun", 1500);
		SBAccount sb4 = new SBAccount(1003, "Anu", 5000);
		expectedList.add(sb1);
		expectedList.add(sb2);
		expectedList.add(sb3);
		expectedList.add(sb4);
	}

	@Test

	public void testGetAllSBAccounts() {

		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		List<SBAccount> actualList = sBAccountDAOImpl.getAllSBAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}

	@Test

	public void testGetSBAccountByAccountNo() {

		String expectedValue = "Anu";

		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		SBAccount actualValue = sBAccountDAOImpl.getSBAccountByAccountNo(1003);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}

	@Test

	public void testDeleteSBAccount() {

		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		sBAccountDAOImpl.deleteSBAccount(1002);
		

		List<SBAccount> actualValue = sBAccountDAOImpl.getAllSBAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());

	}

}
