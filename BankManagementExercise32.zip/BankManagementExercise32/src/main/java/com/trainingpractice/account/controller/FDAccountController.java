/**
 * FDAccountController
 * 
 * FDAccountController  @controller annotation is used to declare the class as a controller
 *
 * 15/10/20
 * 
*/

package com.trainingpractice.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.trainingpractice.account.model.CurrentAccount;
import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.service.FDAccountService;
/**
 * FDAccountController @controller annotation is used to declare the class as a controller.we created service class object 
 */
@Controller
public class FDAccountController {
	@Autowired
	private FDAccountService service;
	
	/**
	 * @Requestmapping annotation is used to map the class with the specified URL name.
	 */
	@RequestMapping("/fDAccounts")
	/**
	 * getAllFDAccounts method which returns a fDAccountList jsp page
	 */
	public String getAllFDAccounts(Model model) {
		System.out.println("inside getAllFDAccounts");
		List<FDAccount> fDAccountsList=service.getAllFDAccounts();
		model.addAttribute("fDAccounts",fDAccountsList);
		return "fDAccountList";
}
	/**
	 * getCurrentAccount is  a method to dispaly particular account details .
	 */	
	@RequestMapping("/viewFDAccount")
	public String getFDAccount(@RequestParam("accNo") String accNo,Model model ) {
	
		FDAccount fDAccount=service.getFDAccountByAccountNo(Integer.parseInt(accNo));
	model.addAttribute("key", fDAccount);
	return "viewFDAccount";
	
		
		
}
}