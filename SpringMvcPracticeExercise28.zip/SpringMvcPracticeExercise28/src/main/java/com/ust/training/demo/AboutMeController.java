/**
 * AboutMeController
 * AboutMeController is a controller class it have a  method getMyHobbies().
 * 14-10-2020
 */


package com.ust.training.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * controller class with have a getMethod() return hobbies
 */
@Controller
public class AboutMeController {

	/**
	 * getMyHobbies is a method which return a string
	 */

	@RequestMapping("/hobbies")
	public String getMyHobbies() {
		return "hobbies";
	}
}
