/**
 * FDAccountTestCase
 * FDAccountTestCase  is for performing jUnit test operations
 * 10/6/2020
*/

package com.trainingpractice.model;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;
/** 
 * This class Contains test cases
*/
public class FDAccountTestCase {
	/**
	 * This test case is for  testing whether expected and actual values are same
	*/
	@Test
	void testIsAutoRenewal() {
		boolean expectedValue=false;
		FDAccount fdAcc=new FDAccount();
		fdAcc.autoRenewal(12);
		boolean actualValue=fdAcc.isAutoRenewal();
		
		assertEquals(expectedValue,actualValue);
		
	}

}
