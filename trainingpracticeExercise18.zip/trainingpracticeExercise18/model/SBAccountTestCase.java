package com.trainingpractice.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SBAccountTestCase {

	@Test
	void testWithdrawMoneyFloat() {
		float expectedValue=30000;
		SBAccount acc=new SBAccount();
		acc.withdrawMoney(20000);
		float actualValue=acc.getBalance();
		assertEquals(expectedValue, actualValue);
	}
	
}
