/**
 * LoanAccountSortDemo
 * LoanAccountSortDemo  is printing all  FDAccounts and also sorted list based on account holder name and LoanOutStanding
 * 10/6/2020
*/

package com.trainingpractice.service;
/**
 * printing all  LoanAccount and also sorted list based on account holder name and  LoanOutStanding.
 
 */
public class LoanAccountSortDemo {

	public static void main(String[] args) {
		LoanAccountService service=new LoanAccountService ();
		System.out.println("Print all FD Accounts");
		service.getAllLoanAccounts();
		
		System.out.println("--------------");
		System.out.println();
		System.out.println("print all account holder name after sorting");
		service.getAllLoanAccountsSortedByAccountHolderName();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print all accounts after sorting based on LoanOutStanding");
		service.getAllLoanAccountsSortedByLoanOutStanding();

	}

}
