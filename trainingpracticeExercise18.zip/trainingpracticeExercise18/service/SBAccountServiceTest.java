/**
 * SBAccountServiceTest
 * SBAccountServiceTest  is for performing JUnit test 
 * 10/6/2020
*/

package com.trainingpractice.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.trainingpractice.dataaccess.SBAccountDAOImpl;
import com.trainingpractice.model.FDAccount;
import com.trainingpractice.model.SBAccount;

/**
 * This class Contains various test cases
 */
public class SBAccountServiceTest {
	SBAccountService sBAccountService;
	/**
	 * Constructor for LoanAccountServiceTest
	 */
	public SBAccountServiceTest() {
		sBAccountService= new SBAccountService();
		sBAccountService.addSBAccount(new SBAccount(1000, "Akhila", 2000));
		sBAccountService.addSBAccount(new SBAccount(1003, "Anu", 5000));
		
	}
	/**
	 * Test Method to add account successfully
	 */
	@Test
	void testAddCurrentAccountSuccess() {
		int expectedValue = 3;
		
		sBAccountService.addSBAccount(new SBAccount(1005, "Anagha", 60000));
		List<SBAccount> actualValue = sBAccountService.getAllSBAccounts();
		assertEquals(expectedValue, actualValue.size());

	}
	/**
	 * Test Method if there is failure to add account
	 */
	@Test
	public void testAddCurrentAccountFailure() {
		String expected ="Anu";
    	sBAccountService.addSBAccount(new SBAccount(1003, "Akhila", 5000));
	     String actual = sBAccountService.getSBAccountByAccountNo(1003).getAccountHolderName();
		assertEquals(expected, actual); 
		
			
		}
	/**
	 * Test method to update account
	 */
	@Test
	  public void testUpdateSBAccountSuccess() {
		  
		sBAccountService.updateSBAccount(new SBAccount(1000, "Akhila", 6000));
		float actual = sBAccountService.getSBAccountByAccountNo(1000).getBalance();
		float expected = 6000;
		assertEquals(expected, actual);

}
	
}
	
		/*expectedList = new ArrayList<SBAccount>();
		SBAccount sb1 = new SBAccount(1000, "Akhila", 2000);
		SBAccount sb2 = new SBAccount(1001, "Anjali", 1000);
		SBAccount sb3 = new SBAccount(1002, "Arun", 1500);
		SBAccount sb4 = new SBAccount(1003, "Anu", 5000);
		expectedList.add(sb1);
		expectedList.add(sb2);
		expectedList.add(sb3);
		expectedList.add(sb4);
	}

	*//**
	 * This test case is for testing whether expected and actual values are same
	 *//*
	@Test
	void testGetAllSBAccounts() {
		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		List<SBAccount> actualList = sBAccountDAOImpl.getAllSBAccounts();

		assertEquals(expectedList.size(), actualList.size());
	}

	*//**
	 * This test case is for testing whether expected and actual values are same
	 *//*
	@Test
	void testGetSBAccountByAccountNo() {
		String expectedValue = "Anu";

		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		SBAccount actualValue = sBAccountDAOImpl.getSBAccountByAccountNo(1003);

		assertEquals(expectedValue, actualValue.getAccountHolderName());
	}

	*//**
	 * This test case is for testing whether expected and actual values are same
	 *//*
	@Test
	void testDeleteSBAccount() {
		SBAccountDAOImpl sBAccountDAOImpl = new SBAccountDAOImpl();

		sBAccountDAOImpl.deleteSBAccount(1002);

		List<SBAccount> actualValue = sBAccountDAOImpl.getAllSBAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());
	}

	*//**
	 * This test case is for testing whether expected and actual values are same
	 *//*
	@Test
	void testGetAllSBAccountsSortedByAccountHolderName() {
		String expected = "Anjali";
		SBAccountService sBService = new SBAccountService();
		SBAccount actual = sBService.getAllSBAccountsSortedByAccountHolderName().get(1);
		assertEquals(expected, actual.getAccountHolderName());
	}

	*//**
	 * This test case is for testing whether expected and actual values are same
	 *//*
	@Test
	void testGetAllSBAccountsSortedByBalance() {
		String expected = "Arun";
		SBAccountService sBService = new SBAccountService();
		SBAccount actual = sBService.getAllSBAccountsSortedByBalance().get(1);
		assertEquals(expected, actual.getAccountHolderName());
	}
*/


