/**
 * CurrentAccountComparator
 * 
 *  CurrentAccountComparator class is implemented from Comparator
 *
 * Date:07/10/2020
 * 
*/


package com.trainingpractice.service;

import java.util.Comparator;

import com.trainingpractice.model.CurrentAccount;
/**
*Class is for performing sorting overdraft limit in current accounts .
*/
public class CurrentAccountComparator  implements Comparator<CurrentAccount>{
	/**
	 * method for sorting by OverDraftLimit
	 */
	@Override
	public int compare(CurrentAccount o1, CurrentAccount o2) {
	
		return (int)(o1.getOverDraftLimit()-o2.getOverDraftLimit());
	}
	
	

}
