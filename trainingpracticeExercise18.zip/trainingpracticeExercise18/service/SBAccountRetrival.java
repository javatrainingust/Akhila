/**
	 *  SBAccountRetrival
	 *  SBAccountRetrival is class for retrieving all FDAccounts and also retrieving A particular account
	 * 10/6/2020
	*/

package com.trainingpractice.service;
/**
 * class for retrieving all SBAccounts
*/

public class SBAccountRetrival {
	
	public static void main(String[] args) {
		SBAccountService service =  new SBAccountService();
		
		
		/*retrieving all SBAccounts*/
		
		service.getAllSBAccounts();
		
		System.out.println("----------------------------------");
		
		
		service.getSBAccountByAccountNo(1002);

	}

	}


