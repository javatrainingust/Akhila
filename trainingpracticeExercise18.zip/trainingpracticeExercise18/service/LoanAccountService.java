/**
 * LoanAccountService
 * 
 *LoanAccountService class is a  class 
 *
 * Date:06/10/2020
 * 
*/


package com.trainingpractice.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.trainingpractice.dataaccess.LoanAccountDAO;
import com.trainingpractice.dataaccess.LoanAccountDAOImpl;
import com.trainingpractice.model.LoanAccount;
/** 
 *class used for add,delete,get the Current account details
*/
public class LoanAccountService {
	LoanAccountDAO loanAccountDAOImpl;

	public LoanAccountService() {

		loanAccountDAOImpl = new LoanAccountDAOImpl();

	}
	/**
	 *  getAllLoanAccounts method is for getting all the LoanAccount
	*/
	public List<LoanAccount> getAllLoanAccounts() {

		List<LoanAccount> loanAccountList = loanAccountDAOImpl.getAllLoanAccounts();
		Iterator<LoanAccount> iterator = loanAccountList.iterator();

		while (iterator.hasNext()) {

			LoanAccount la = iterator.next();

			System.out.println("Account No is= " + la.getAccountNo());
			System.out.println("Accont holder name is = " + la.getAccountHolderName());
			
			System.out.println("Account loan outstanding is= " + la.getLoanOutStanding());
		}

		return loanAccountList;

	}
	/**
	 *  getLoanAccountByAccountNo method is for getting the particular  LoanAccount
	 */
	public LoanAccount getLoanAccountByAccountNo(int accountNo) {

		LoanAccount la = loanAccountDAOImpl.getLoanAccountByAccountNo(accountNo);

		System.out.println("Account No is= " + la.getAccountNo());
		System.out.println("Accont holder name is = " + la.getAccountHolderName());
		System.out.println("Account loan outstanding is= " + la.getLoanOutStanding());
		return la;

	}
	/**
	 * deleteLoanAccount method is for deleting a particular  LoanAccount
	*/
	public void deleteLoanAccount(int accountNo) {

		loanAccountDAOImpl.deleteLoanAccount(accountNo);

	}
	/**
	 * method for sorting LoanAccount by account holder name
	 */
	public List<LoanAccount> getAllLoanAccountsSortedByAccountHolderName() {
		List<LoanAccount> loanAccountList = loanAccountDAOImpl.getAllLoanAccounts();
		Collections.sort(loanAccountList);
		Iterator<LoanAccount> iterator = loanAccountList.iterator();

		while (iterator.hasNext()) {

			LoanAccount la = iterator.next();

			System.out.println("Account No is= " + la.getAccountNo());
			System.out.println("Accont holder name is = " + la.getAccountHolderName());
			System.out.println("Account loan outstanding is= " + la.getLoanOutStanding());

		}

		return loanAccountList;
		
	}
	/**
	 * method for sorting LoanAccount by LoanOutStanding
    */
	public List<LoanAccount> getAllLoanAccountsSortedByLoanOutStanding() {
		
		List<LoanAccount> loanAccountList = loanAccountDAOImpl.getAllLoanAccounts();
		Collections.sort(loanAccountList,new LoanAccountComparator());
		Iterator<LoanAccount> iterator = loanAccountList.iterator();

		while (iterator.hasNext()) {

			LoanAccount la = iterator.next();

			System.out.println("Account No is= " + la.getAccountNo());
			System.out.println("Accont holder name is = " + la.getAccountHolderName());
			System.out.println("Account loan outstanding is= " + la.getLoanOutStanding());

		}

		return loanAccountList;
	}
	
	/**
	 * method for adding  LoanAccount
    */
	public void addLoanAccount(LoanAccount loanAccount){
	boolean isAdded = loanAccountDAOImpl.addLoanAccount(loanAccount);
	
	if(!isAdded){
		
		System.out.println("The Account holder already exist");
	}
	else{
		System.out.println("The Account holder is  successfully added");
		
	}
	}
	/**
	 * method for updating  LoanAccount
    */
	public void updateLoanAccount(LoanAccount loanAccount) {
	loanAccountDAOImpl.updateLoanAccount(loanAccount);
}
}
