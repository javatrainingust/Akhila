/**
 *  CurrentAccountDelete 
 *  CurrentAccountDelete is class for retrieving all FDAccounts before deletion and also deleting  a particular account
 * 10/6/2020
*/
package com.trainingpractice.service;
/**
 * Class for retrieving all Current account and deleting a particular Current account  and results printed
 */
public class CurrentAccountDelete {

	public static void main(String[] args) {
		CurrentAccountService service =  new CurrentAccountService();
		
		System.out.println();
		System.out.println("all current Accounts are retrieved");
		
		service.getAllCurrentAccounts();
				
		
		service.deleteCurrentAccount(1003);
		System.out.println("----------------------------------");
		
		System.out.println();
		System.out.println("After deletion");
		
		service.getAllCurrentAccounts();


	}

}
