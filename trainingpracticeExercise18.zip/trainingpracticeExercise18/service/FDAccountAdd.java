/**
 *  FDAccountAdd 
 *  FDAccountAdd  is an class for printing the account details after adding and updating 
 * 10/8/2020
*/

package com.trainingpractice.service;

import com.trainingpractice.model.FDAccount;
/**
 * Main method for printing the account details after adding and updating 
 */
public class FDAccountAdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FDAccountService service=new FDAccountService();
		service.addFDAccount(new FDAccount(1000, "Akhila",20000));
		service.addFDAccount(new FDAccount(1001, "Anjali", 10000));
		System.out.println("Printing all Accounts");	
		service.getAllFDAccounts();
		
		System.out.println("---------------------------------------------");	
	service.updateFDAccount(new FDAccount(1001, "Anjali", 50000));
		
		System.out.println("Printing all updated accounts");	
	service.getAllFDAccounts();
	}

}
