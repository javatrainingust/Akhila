/**
 *  SBAccountAdd
 *  SBAccountAdd is an class for printing the account details after adding and updating 
 * 10/8/2020
*/

package com.trainingpractice.service;


import com.trainingpractice.model.SBAccount;
/**
 * Main method for printing the account details after adding and updating 
 */
public class SBAccountAdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SBAccountService service=new SBAccountService();
	service.addSBAccount(new SBAccount(1000, "Akhila", 2000));
	service.addSBAccount(new SBAccount(1003, "Anu", 5000));
	
		System.out.println("Printing all Accounts");	
		service.getAllSBAccounts();
		
		System.out.println("---------------------------------------------");	
service.updateSBAccount(new SBAccount(1003, "Arya", 5000));
		
		System.out.println("Printing all updated Accounts");	
		service.getAllSBAccounts();
	}

}
