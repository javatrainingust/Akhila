/**
 * LoanAccountDAOImplTest
 * LoanAccountDAOImplTest is a class for performing JUnit testing
 * 10/6/2020
*/

package com.trainingpractice.dataaccess;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.trainingpractice.model.LoanAccount;
/**
  * LoanAccountDAOImplTest is a class for performing JUnit testing
*/

public class LoanAccountDAOImplTest {

	List<LoanAccount> expectedList;
	/**
	* Constructor of LoanAccountDAOImplTest class
	*/
	public LoanAccountDAOImplTest()

	{
		expectedList = new ArrayList<LoanAccount>();
		LoanAccount la1 = new LoanAccount(1000, "Akhila", 2000);
		LoanAccount la2 = new LoanAccount(1001, "Sonu", 1000);
		LoanAccount la3 = new LoanAccount(1002, "Arun", 1500);
		LoanAccount la4 = new LoanAccount(1003, "Anu", 5000);
		expectedList.add(la1);
		expectedList.add(la2);
		expectedList.add(la3);
		expectedList.add(la4);
	}

	@Test

	public void testGetAllLoanAccounts() {

		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();

		List<LoanAccount> actualList = loanAccountDAOImpl.getAllLoanAccounts();

		assertEquals(expectedList.size(), actualList.size());

	}

	@Test

	public void testGetLoanAccountByAccountNo() {

		String expectedValue = "Anu";

		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();

		LoanAccount actualValue = loanAccountDAOImpl.getLoanAccountByAccountNo(1003);

		assertEquals(expectedValue, actualValue.getAccountHolderName());

	}

	@Test

	public void testDeleteLoanAccount() {

		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();

		loanAccountDAOImpl.deleteLoanAccount(1002);
		

		List<LoanAccount> actualValue = loanAccountDAOImpl.getAllLoanAccounts();

		assertEquals(expectedList.size() - 1, actualValue.size());

	}

}
