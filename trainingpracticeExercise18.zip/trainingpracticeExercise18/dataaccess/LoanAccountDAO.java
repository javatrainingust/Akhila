/**
 * LoanAccountDAO 
 * LoanAccountDAO is an interface which contains the methods  for implementation class
 * 10/6/2020
*/
package com.trainingpractice.dataaccess;

import java.util.List;

import com.trainingpractice.model.LoanAccount;
import com.trainingpractice.model.SBAccount;


public interface LoanAccountDAO {
	public List<LoanAccount> getAllLoanAccounts();
	public LoanAccount getLoanAccountByAccountNo(int accountNo );
	public void deleteLoanAccount(int accountNo);
	public boolean addLoanAccount(LoanAccount loanAccount);
	public void updateLoanAccount(LoanAccount loanAccount);

}
