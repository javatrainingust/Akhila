package com.trainingpractice.dataaccess;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


import com.trainingpractice.model.FDAccount;
/**
 * FDAccountDAOImpl
 * FDAccountDAOImpl is an implementation class for FDAccountDAO
 * 10/6/2020
*/
public class FDAccountDAOImpl implements FDAccountDAO {
	List<FDAccount> fDAccountList;
	private Set fDAccountSet;
	public FDAccountDAOImpl() {
		fDAccountList = new ArrayList<FDAccount>();
		fDAccountSet= new HashSet<FDAccount>();
		/*FDAccount fd1 = new FDAccount(1000, "Akhila", 20000);
		FDAccount fd2 = new FDAccount(1001, "Anjali", 10000);
		FDAccount fd3 = new FDAccount(1002, "Arun", 15000);
		FDAccount fd4 = new FDAccount(1003, "Anu", 8000);
		fDAccountList.add(fd1);
		fDAccountList.add(fd2);
		fDAccountList.add(fd3);
		fDAccountList.add(fd4);*/

	}
	/* getAllFDAccounts method is for getting all the FDAccount*/

	@Override
	public List<FDAccount> getAllFDAccounts() {

		return fDAccountList;
	}
	/* getFDAccountByAccountNo method is for getting the particular  FDAccount*/

	@Override
	public FDAccount getFDAccountByAccountNo(int accountNo) {
		FDAccount fDAccount = null;
		Iterator<FDAccount> iterator = fDAccountList.iterator();
		while (iterator.hasNext()) {
			FDAccount fdAccount2 = (FDAccount) iterator.next();
			if (fdAccount2.getAccountNo() == accountNo) {
				fDAccount = fdAccount2;

			}

		}
		return fDAccount;
	}
	/* deleteFDAccount method is for deleting a particular  FDAccount*/

	@Override
	public void deleteFDAccount(int accountNo) {
		FDAccount fDAccount = null;
		for (int i = 0; i < fDAccountList.size(); i++) {
			fDAccount = (FDAccount) fDAccountList.get(i);
			if (fDAccount.getAccountNo() == accountNo) {
				fDAccountList.remove(i);
			}

		}
	}

	@Override
	public boolean addFDAccount(FDAccount fDAccount) {
		boolean  isAdded=fDAccountSet.add(fDAccount);
		if(isAdded) {
			fDAccountList.add(fDAccount);
		}
		return isAdded;
	}

	@Override
	public void updateFDAccount(FDAccount fDAccount) {
		Iterator<FDAccount> iterator=fDAccountList.iterator();
		while (iterator.hasNext()) {
			FDAccount fd = (FDAccount) iterator.next();
			if(fd.getAccountNo()==fDAccount.getAccountNo()) {
				
				fd.setAccountHolderName(fDAccount.getAccountHolderName());
				fd.setAccountNo(fDAccount.getAccountNo());
				fd.setBalance(fDAccount.getBalance());
			}
			
		}
		
	}

}
