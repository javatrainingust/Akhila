/**
 * AboutMeController
 * AboutMeController is a controller class it have a  method getMyHobbies() which return a jsp page.
 * 14-10-2020
 */


package com.ust.training.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class AboutMeController {
	
	/**
	 * getMyHobbies is a method which return a string
	 */
	
	@RequestMapping("/hobbies")
	public String getMyHobbies() {
		return "aboutme";
	}
	/**
	 *  method process  which takes hobby as requestparam  return a string
	 */
	@RequestMapping("/ProcessForm")
	public String process(  @RequestParam("hobby") String myHobby,Model model) {
		// create the message
				String result = "My hobby is  " + myHobby;
				
				// add message to the model
				model.addAttribute("message", result);
						
		
		return "myhobbies";
	}
}

