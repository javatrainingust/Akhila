/**
 *  Controller Class
 * 
 * Controller class denotes the class as a controller
 *
 * 22/10/2020
 * 
*/
package com.ust.training.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.training.model.CountryDetails;

/**
 * @RestController is a specialized version of the controller. It includes the @Controller and @ResponseBody annotations and as a result, simplifies the controller implementation
 *                 
 *               
 */
@RestController
public class Controller {
	Map<String, CountryDetails> countryDB = new HashMap<String, CountryDetails>();

	/**
	 * Request method to GET the countries here we passed dummy values for country.
	 */
	@RequestMapping(value = "/countries/dummy", method = RequestMethod.GET)
	public CountryDetails getDummyCountryDetails() {

		CountryDetails country = new CountryDetails();

		country.setCode("IN");
		country.setDescription("India");
		country.setMessage("Dummy created");
		countryDB.put("IN", country);

		return country;

	}

	/**
	 * RequestMethod GET countries based on the country code
	 */
	@RequestMapping(value = "/countries/{code}", method = RequestMethod.GET)
	public CountryDetails getCountryDetails(@PathVariable String code) {

		CountryDetails country = new CountryDetails();

		if (countryDB.containsKey(code)) {
			country = countryDB.get(code);
			country.setMessage("Country Retreived");
		} else {
			country.setMessage("Country not found");
		}
		return country;

	}

	/**
	 * RequestMethod GET all countries in the given list
	 */
	@RequestMapping(value = "/countries", method = RequestMethod.GET)
	public List<CountryDetails> getAllCountryDetails() {

		List<CountryDetails> countries = new ArrayList<CountryDetails>();

		Set<String> countryCodeKeys = countryDB.keySet();
		for (String string : countryCodeKeys) {
			countries.add(countryDB.get(string));

		}
		return countries;

	}

	/**
	 * RequestMethod POST all countries in the given list
	 */
	@RequestMapping(value = "/countries", method = RequestMethod.POST)
	public CountryDetails createCountryDetails(@RequestBody CountryDetails country) {

		System.out.println("country code: " + country.getCode());
		if (countryDB.containsKey(country.getCode())) {

			country.setMessage("Country already exist");

		} else {

			countryDB.put(country.getCode(), country);
			country.setMessage("country created");

		}

		return country;

	}

	/**
	 * RequestMethod DELETE to delete a country based on code
	 */
	@RequestMapping(value = "/countries/{code}", method = RequestMethod.DELETE)
	public CountryDetails deleteCountryDetails(@PathVariable String code) {

		CountryDetails country = new CountryDetails();

		if (countryDB.containsKey(code)) {
			country = countryDB.get(code);

			countryDB.remove(code);

			country.setMessage("country deleted");

		} else {

			country.setMessage("country not found");

		}

		return country;

	}

	/**
	 * RequestMethod PUT to update country based on code
	 */

	@RequestMapping(value = "/countries/{code}", method = RequestMethod.PUT)
	public CountryDetails updateCountryDetails(@PathVariable String code,
			@RequestBody CountryDetails ModifiedCountryDetail) {

		CountryDetails country = new CountryDetails();

		if (countryDB.containsKey(code)) {

			country = countryDB.get(code);
			country.setDescription(ModifiedCountryDetail.getDescription());

			country.setMessage("Country updated");

		} else {
			country.setMessage("Country not found");

		}

		return country;
	}
}
