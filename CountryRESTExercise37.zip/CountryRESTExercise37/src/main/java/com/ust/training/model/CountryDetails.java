/**
 * CountryDetails Class
 * 
 * CountryDetails  class is a model class which contains fields code description,message
 *
 * 22/10/2020
 * 
*/
package com.ust.training.model;

/**
 *  * CountryDetails  class is a model class which contains fields code description,message

 */
public class CountryDetails {
	private String code ;

	private String description;
	private String message;
	/**
	 * getter for code
	*/
	public String getCode() {
		return code;
	}
	/**
	 * setter for code
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * getter for description
	 */
	
	public String getDescription() {
		return description;
	}
	/**
	 * setter for description
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * getter for message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * setter for message
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	

}
