package com.trainingpractice.account.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SBAccountTestCase {

	@Test
	void testWithdrawMoneyFloat() {
		float expectedValue=30000;
		SBAccount acc=new SBAccount();
		
		try {
			acc.withdrawMoney(20000);
		} catch (InsufficientBalanceException e) {
			
			e.printStackTrace();
		}
		
		float actualValue=acc.getBalance();
		assertEquals(expectedValue, actualValue);
	}
	
}
