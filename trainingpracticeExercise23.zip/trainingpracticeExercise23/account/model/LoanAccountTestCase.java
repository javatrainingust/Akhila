package com.trainingpractice.account.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LoanAccountTestCase {

	@Test
	void testCalculateEMI() {
		int expectedValue=100;
		LoanAccount loan=new LoanAccount();
		loan.calculateEMI(1200);
		float actualValue= loan.getEmi();
		assertEquals(expectedValue,actualValue);
		
		
		
	}

		 


}
