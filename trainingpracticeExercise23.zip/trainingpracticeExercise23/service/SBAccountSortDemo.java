
/**
 * SBAccountSortDemo
 * SBAccountSortDemo  is printing all  FDAccounts and also sorted list based on account holder name and Balance
 * 10/6/2020
*/
package com.trainingpractice.service;

/**
 * printing all SBAccounts and also sorted list based on account holder name and
 * Balance.
 * 
 */

public class SBAccountSortDemo {

	public static void main(String[] args) {
		SBAccountService sBService = new SBAccountService();
		System.out.println("Print all FD Accounts");
		sBService.getAllSBAccounts();

		System.out.println("--------------");
		System.out.println();
		System.out.println("print all account holder name after sorting");
		sBService.getAllSBAccountsSortedByAccountHolderName();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print all accounts after sorting based on balance");
		sBService.getAllSBAccountsSortedByBalance();
	}

}


