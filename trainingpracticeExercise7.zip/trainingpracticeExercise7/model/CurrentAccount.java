package com.trainingpractice.model;

public class CurrentAccount extends Account {
public float overDraftLimit=2000;

	public void AmountLimit(float balance) {
		if(balance<overDraftLimit) {
			System.out.println("Eligible for overdraft");
		}
		else {
			System.out.println("Not eligible for overdrafting");
		}
	
	}
}
	
	
	
