package com.trainingpractice.generic;

import com.trainingpractice.calculation.IntrestCalculation;
import com.trainingpractice.model.Account;
import com.trainingpractice.model.FDAccount;
import com.trainingpractice.model.SBAccount;

public class GenericService {
	public static void main(String[] args) {
		FDAccount fd=new FDAccount();
		fd.setAccountHolderName("Arun");
		fd.setAccountNo(231);
		
		SBAccount sb=new SBAccount();
		sb.setAccountHolderName("Sona");
		sb.setAccountNo(8789);
		Account[] e = {new Account(),fd,sb};
		IntrestCalculation interest=new IntrestCalculation();
		for (Account account : e) {
			account.interestCalculation(2000, interest);
			if (account instanceof FDAccount) {
				FDAccount fd1=(FDAccount)account;
				fd1.autoRenewal(12);
				
				
			}
			

		}
		
	}

}
  

 
