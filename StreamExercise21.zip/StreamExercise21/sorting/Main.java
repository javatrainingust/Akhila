
package com.trainingpractice.function.sorting;

import java.util.ArrayList;

import java.util.List;

import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		List<Cat> cats = new ArrayList<Cat>();

		Cat cat1 = new Cat("Snow", 2);

		Cat cat2 = new Cat("kitty", 3);

		Cat cat3 = new Cat("Dora", 1);

		Cat cat4 = new Cat("Simba", 4);

		cats.add(cat1);
		cats.add(cat2);
		cats.add(cat3);
		cats.add(cat4);

		Stream<Cat> catStream = cats.stream();

		Stream<Cat> sortedCatStream = catStream.sorted();

		sortedCatStream.forEach((e) -> System.out.println(e));
	}
}
