/**
 * SortDemo 
 * SortDemo  is a class for Creating a list of strings displaying the stream with elements and sorted
 * 10/9/2020
*/



package com.trainingpractice.function.sort;

import java.util.stream.Stream;

public class SortDemo {

	public static void main(String[] args) {

		// Creating a list of strings displaying the stream with elements and sorted

		Stream<String> sortedStream = Stream.of("Akhila", "Arun", "Vignesh", "Anjali", "Bastin").sorted();
		sortedStream.forEach((e) -> System.out.println(e));

	}

}
