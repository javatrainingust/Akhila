/**
 * StreamInteger 
 * 10/9/2020
*/


package com.trainingpractice.function.sort;

import java.util.stream.Stream;
 
public class StreamInteger {

	public static void main(String[] args) {

		Stream<Integer> numbers = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9);
		long result = numbers.map((n) -> (n * 2)).filter((i) -> (i > 10)).count();

		System.out.println("The result is =" + result);

	}

}
