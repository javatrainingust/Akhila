/**
 * CurrentAccount
 * 
 * CurrentAccount extends to Account class it consist of AmountLimit method
 *
 * 30/9/2020
 * 
*/

package com.trainingpractice.model;

/**
 * class to perform account operation of CurrentAccount
*/
public class CurrentAccount extends Account {
	public float overDraftLimit = 2000;
	float balance=1000;

	public CurrentAccount() {

		System.out.println("Inside current account no arg constructor");
	}

	

	public CurrentAccount(float balance) {
		super();
		this.balance = balance;
		System.out.println("inside parameterized constructor of current account");
	}



	public void AmountLimit(float balance) {
		if (balance < overDraftLimit) {
			System.out.println("Eligible for overdraft");
		} else {
			System.out.println("Not eligible for overdrafting");
		}

	}
}
	
	
