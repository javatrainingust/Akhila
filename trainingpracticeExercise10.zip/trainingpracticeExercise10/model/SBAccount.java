/**
 * SBAccount 
 * 
 * CSBAccount  extends to Account class it consist of withdrawMoney method and interestCalculation method
 *
 * 30/9/2020
 * 
*/


package com.trainingpractice.model;
/**
 * SBAccount class extends Account class it  has 2 methods, withdrawMoney for withdrawing money and interestCalculation for calculating interest
 */

import com.trainingpractice.calculation.ICalculator;
import com.trainingpractice.calculation.IntrestCalculation;

public class SBAccount extends Account {

    public float balance=400000;
	IntrestCalculation interest=new IntrestCalculation();
	private int rate;
	private float interestRate;
	private int principal;
	private float duration;
	public SBAccount() {
		System.out.println("Inside SB account no arg constructor");
	}
	
	public SBAccount(float balance, float duration) {
		super();
		this.balance = balance;
		this.duration = duration;
		System.out.println("parameterized constructor of sb account");
	}


	public float getbalance() {
          return balance;
    }
    
    public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getPrincipal() {
		return principal;
	}

	public void setPrincipal(int principal) {
		this.principal = principal;
	}
/*withdrawMoney method to know the withdrawal amount from bank */
	
	public void withdrawMoney(float amountWithdrawn)
    {
          balance=balance- amountWithdrawn;
          System.out.println("Account balance after withdrawing is :" +balance);
    }

//    @Override
//    public void caluculateInterest() {
//    	
//    	interestRate=(principal*rate*1)/100;
//    	System.out.println("The simple interest rate for SBAccount is="+interestRate);
//    }
	/*interestCalculation method takes 2 arguments*/
	public void interestCalculation(float amount,ICalculator interest) {
		float interestsb=interest.calculateInterest(amount,duration);
		System.out.println("The interest for SB="+interestsb);
	}
}




