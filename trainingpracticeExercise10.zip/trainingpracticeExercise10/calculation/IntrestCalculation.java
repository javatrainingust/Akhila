package com.trainingpractice.calculation;
/**
 * 
 * IntrestCalculation
 *implements methods of ICalculator
 * 30/9/2020
 */
public class IntrestCalculation implements ICalculator {
float fdRate=0.3f;
float sbRate=0.7f;
float  duration=1;
//calculating FD simple interest

public float calculateInterest(float amount) {
	float interestamountfd = (amount * fdRate * duration) / 100;
	return interestamountfd;
}
//calculating SB simple interest
public float calculateInterest(float amount, float duration) {
	float sbinterestamount = (amount * sbRate * duration) / 100;
	return sbinterestamount;
}

} 