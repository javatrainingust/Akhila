/**
 * CurrentAccountSortDemo 
 * CurrentAccountSortDemo  is printing all  CurrentAccount and also sorted list based on account holder name and over draft limit
 * 10/6/2020
*/


package com.trainingpractice.account.service;

/**
 * printing all  CurrentAccount and also sorted list based on account holder name and over draft limit.
 
 */

public class CurrentAccountSortDemo {

	public static void main(String[] args) {
		CurrentAccountService currentService=new CurrentAccountService ();
		System.out.println("Print all FD Accounts");
		currentService.getAllCurrentAccounts();
		
		System.out.println("--------------");
		System.out.println();
		System.out.println("print all account holder name after sorting");
		currentService.getAllCurrentAccountsSortedByAccountHolderName();
		System.out.println("----------------------");
		System.out.println();
		System.out.println("Print all accounts after sorting based on overdraftlimit");
		currentService.getAllCurrentAccountsSortedByOverDraftLimit();

	}

}
