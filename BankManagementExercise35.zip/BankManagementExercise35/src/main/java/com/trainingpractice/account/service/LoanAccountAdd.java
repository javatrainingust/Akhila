
/**
 *  LoanAccountAdd
 *  LoanAccountAdd is an class for printing the account details after adding and updating 
 * 10/8/2020
*/
package com.trainingpractice.account.service;

import com.trainingpractice.account.model.LoanAccount;

public class LoanAccountAdd {
/**
 * Main method for printing the account details after adding and updating 
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoanAccountService service = new LoanAccountService();

		service.addLoanAccount(new LoanAccount(1000, "Akhila", 2000));
		service.addLoanAccount(new LoanAccount(1001, "Sonu", 1000));

		System.out.println("Printing all Accounts");
		service.getAllLoanAccounts();

		System.out.println("---------------------------------------------");
		service.updateLoanAccount(new LoanAccount(1001, "Sonu", 2500));

		System.out.println("Printing all updated accounts");
		service.getAllLoanAccounts();

	}

}
