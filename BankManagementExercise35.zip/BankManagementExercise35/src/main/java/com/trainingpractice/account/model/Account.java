/**
 * Account Class
 * 
 * Account  class consist of private variables interestCalculation method
 *
 * 30/9/2020
 * 

*/
package com.trainingpractice.account.model;
/***
 * Account class have private variables and provide public  setters and getters (encapsulation)
 */

import com.trainingpractice.account.interestcalculation.ICalculator;


public class Account {
	private int accountNo;
	protected String accountHolderName;
	protected float balance=50000;
	public Account() {
		System.out.println("No argument constructor of Account class");
		
	}
	
	
	public Account(int accountNo, String accountHolderName,float balance) {
		
		this.accountNo = accountNo;
		this.balance=balance;
		this.accountHolderName = accountHolderName;
		System.out.println("parameterized constructor of account class");
	}


	/*
	 * public void caluculateInterest() {
	 * System.out.println("calculating interest"); }
	 */


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNo;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNo != other.accountNo)
			return false;
		return true;
	}


	public int getAccountNo() {
		return accountNo;
	}


	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}


	public String getAccountHolderName() {
		return accountHolderName;
	}


	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}


	public float getBalance() {
		return balance;
	}
	
	public void setBalance(float balance) {
		this.balance = balance;
	}


/*interest calculation*/
public void interestCalculation(float amount,ICalculator interest) {
	
	System.out.println("Inside Account class");
}

}

