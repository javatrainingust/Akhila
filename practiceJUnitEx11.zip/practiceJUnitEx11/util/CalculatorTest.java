package com.practice.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	public void testAdd() {
		int expectedValue=8;
		Calculator calc=new Calculator();
		int actualValue=calc.add(4, 4);
		assertEquals(expectedValue,actualValue);
		
		
	}
	@Test
	public void testSub() {
		int expectedValue=10;
		Calculator calc=new Calculator();
		int actualValue=calc.sub(20,10 );
		assertEquals(expectedValue,actualValue);
		
		
	}

}
