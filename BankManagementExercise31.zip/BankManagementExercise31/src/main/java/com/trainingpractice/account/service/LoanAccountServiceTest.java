/**
 * LoanAccountServiceTest
 * LoanAccountServiceTest  is for performing JUnit test 
 * 10/6/2020
*/

package com.trainingpractice.account.service;



import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.model.LoanAccount;

/** 
 * This class Contains various test cases
*/
class LoanAccountServiceTest {
	LoanAccountService loanAccountService;
	/**
	 * Constructor for LoanAccountServiceTest
	 */
	public LoanAccountServiceTest() {
		loanAccountService= new LoanAccountService();
		loanAccountService.addLoanAccount(new LoanAccount(1000, "Akhila", 2000));
		loanAccountService.addLoanAccount(new LoanAccount(1001, "Sonu", 1000));
	}
	/**
	 * Test Method to add account successfully
	 */
	@Test
	void testAddCurrentAccountSuccess() {
		int expectedValue = 7;
		
		loanAccountService.addLoanAccount(new LoanAccount(1005, "Anagha", 60000));
		List<LoanAccount> actualValue = loanAccountService.getAllLoanAccounts();
		assertEquals(expectedValue, actualValue.size());

	}
	/**
	 * Test Method if there is failure to add account
	 */
	@Test
	public void testAddCurrentAccountFailure() {
		String expected ="Sonu";
		loanAccountService.addLoanAccount(new LoanAccount(1001,"Akhila", 1000));
	
		String actual = loanAccountService.getLoanAccountByAccountNo(1001).getAccountHolderName();
		assertEquals(expected, actual); 
		
			
		}
	/**
	 * Test method to update account
	 */
	@Test
	  public void testUpdateFDAccount() {
		  
		loanAccountService.updateLoanAccount(new LoanAccount(1000, "Akhila", 2000));
		float actual = loanAccountService.getLoanAccountByAccountNo(1000).getLoanOutStanding();
		System.out.println(actual);
		float expected = 2000;
		assertEquals(expected, actual);

}

	/**
	 * This test case is for testing whether expected and actual values are same
	 */
	@Test
	void testGetAllFDAccountsSortedByAccountHolderName() {
		String expected = "Akhila";
		
		LoanAccount actual = loanAccountService.getAllLoanAccountsSortedByAccountHolderName().get(0);
		assertEquals(expected, actual.getAccountHolderName());
	}

	/**
	 * This test case is for testing whether expected and actual values are same
	 */
	@Test
	void testGetAllLoanAccountsSortedByBalance() {
		String expected = "Sonu";
		
		LoanAccount actual = loanAccountService.getAllLoanAccountsSortedByLoanOutStanding().get(1);
		assertEquals(expected, actual.getAccountHolderName());
	}


}