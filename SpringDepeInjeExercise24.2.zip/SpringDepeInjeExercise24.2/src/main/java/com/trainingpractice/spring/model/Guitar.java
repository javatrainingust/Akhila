/**
 * Guitar
 *Guitar  class which implements Instrument interface
 * 12-10-2020
 */


package com.trainingpractice.spring.model;

import com.trainingpractice.spring.util.Instrument;
/**
 * Implementation of  Instrument interface
 */
public class Guitar implements Instrument{
	/**
	 * Play method to display
	 */
	public void play() {
		System.out.println("Playing gitar");
		
	}

}
