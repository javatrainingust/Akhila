
/**
 *Instrument
 * 
 *Instrument class is an interface
 * 
 * 12/10/2020
 * 
 */
package com.trainingpractice.spring.util;
/**
 * Contains of play method
 */
public interface Instrument {
	public void play();

}
