/**
 * PerformanceDemo
 * 
 * PerformanceDemo class for Dependency injection demo
 * 
 * 12/10/2020
 */

package com.trainingpractice.spring.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.trainingpractice.spring.model.Instrumentalist;
import com.trainingpractice.spring.model.Singer;

/**
 * Dependency injection through constructor demo
 */
public class PerformanceDemo {

	public static void main(String[] args) {

		/* loading the definitions from the given XML file */
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		Singer singer = context.getBean("singerObj", Singer.class);

		singer.perform();
		/* Dependency Injection through setter method */
		Instrumentalist instrumentalist = context.getBean("instrumentalistObj", Instrumentalist.class);

		instrumentalist.perform();
		

		
	}

}
