/**
 * OneManBand
 * OneManBand is a class which implements Performer
 * 12-10-2020
 */

package com.trainingpractice.spring.model;

import java.util.Iterator;
import java.util.List;

import com.trainingpractice.spring.util.Instrument;
import com.trainingpractice.spring.util.Performer;
/**
 * OneManBand is a class which implements Performer interface
 */
public class OneManBand implements Performer {
	public List<Instrument> instruments;
	/**
	 * getter for instruments
	 */
	public List<Instrument> getInstruments() {
		return instruments;
	}

	/**
	 * setter for instruments
	 */
	public void setInstruments(List<Instrument> instruments) {
		this.instruments = instruments;
	}

	/**
	 * implementation of perform method
	 */
	public void perform() {

		Iterator iterator = instruments.iterator();
		while (iterator.hasNext()) {
			Instrument instrument = (Instrument) iterator.next();
			instrument.play();

		
		
		
		}
	}
}

	



