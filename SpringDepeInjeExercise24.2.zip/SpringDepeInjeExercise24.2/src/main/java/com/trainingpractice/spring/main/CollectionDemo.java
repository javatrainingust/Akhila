/**
 * CollectionDemo
 * 
 * Dependency injection demo class 
 * 
 * 12/10/2020
 */

package com.trainingpractice.spring.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.trainingpractice.spring.model.OneManBand;

public class CollectionDemo {

	/*
	 * Main method
	 */
	public static void main(String[] args) {

		/* loading the definitions from the given XML file */
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		/* Dependency injection through constructors */

		OneManBand oneManBand = context.getBean("oneManBandObj", OneManBand.class);
		oneManBand.perform();

	}

}