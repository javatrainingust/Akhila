package com.trainingpractice.model;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

class FDAccountTestCase {

	@Test
	void testIsAutoRenewal() {
		boolean expectedValue=false;
		FDAccount fdAcc=new FDAccount();
		fdAcc.autoRenewal(12);
		boolean actualValue=fdAcc.isAutoRenewal();
		
		assertEquals(expectedValue,actualValue);
		
	}

}
