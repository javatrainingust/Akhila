package com.trainingpractice.calculation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class IntrestCalculationTestCase {

	@Test
	void testCalculateInterestFloat() {
		float expectedValue=5.00f;
		IntrestCalculation interestCalc=new IntrestCalculation();
		float actualValue=interestCalc.calculateInterest(1000);
		assertEquals(expectedValue,actualValue,0.0f);
	}

	@Test
	void testCalculateInterestFloatFloat() {
		float expectedValue=7.00f;
		IntrestCalculation interestCalc=new IntrestCalculation();
		float actualValue=interestCalc.calculateInterest(1000, 1);
		assertEquals(expectedValue,actualValue,0.0f);
		
		
	}

}
