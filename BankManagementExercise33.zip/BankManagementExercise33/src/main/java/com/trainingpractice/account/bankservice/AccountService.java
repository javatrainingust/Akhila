package com.trainingpractice.account.bankservice;



import com.trainingpractice.account.interestcalculation.IntrestCalculation;
import com.trainingpractice.account.model.Account;
import com.trainingpractice.account.model.CurrentAccount;
import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.model.Renewable;
import com.trainingpractice.account.model.SBAccount;

public class AccountService {

	public static void main(String[] args) {
		Account acc=new Account();
		acc.setAccountHolderName("Akhila");
		
		acc.setAccountNo(72314);
		System.out.println("Account holder name is ="+acc.getAccountHolderName());
		System.out.println("The account No is:"+acc.getAccountNo());
        CurrentAccount currentAcc=new CurrentAccount();
		currentAcc.AmountLimit(500);
		
		FDAccount fdAcc=new FDAccount();
		fdAcc.setAutoRenewal(true);
		fdAcc.setPrincipal(500);
		fdAcc.setRate(6);
		fdAcc.setTenure(5);
		
		IntrestCalculation interest=new IntrestCalculation();
		fdAcc.interestCalculation(100, interest);
		//fdAcc.interestCalculation(2000);
		//fdAcc.caluculateInterest();
		//fdAcc.updateRenewal("yes");
		
        Renewable renewable=new FDAccount();
		fdAcc.autoRenewal(12);
		//fdAcc.interestCalculation(10000);
		
//		LoanAccount loanAcc=new LoanAccount();
//		loanAcc.setLoanOutStanding(1000);
//		loanAcc.setTenure(12);
//		loanAcc.calculateEMI();
		SBAccount sbAcc=new SBAccount();
		sbAcc.setAccountHolderName("Arya");
		sbAcc.setPrincipal(600);
		sbAcc.setRate(2);
	
		//sbAcc.caluculateInterest();
		//sbAcc.interestCalculation(2000, 2);
		sbAcc.interestCalculation(3000, interest);
		System.out.println("The account holder name is:"+sbAcc.getAccountHolderName());
		
		
	}

}
