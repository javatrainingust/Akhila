/**
 * LoanAccountController
 * 
 * LoanAccountController  @controller annotation is used to declare the class as a controller
 *
 * 15/10/20
 * 
*/

package com.trainingpractice.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.model.LoanAccount;
import com.trainingpractice.account.service.LoanAccountService;

/**
 * LoanAccountController @controller annotation is used to declare the class as a controller.we created service class object
 */
@Controller
public class LoanAccountController {
	@Autowired
	private LoanAccountService service;

	/**
	 * @Requestmapping annotation is used to map the class with the specified URL name.
	 *              
	 */
	@RequestMapping("/loanAccounts")
	/**
	 * getAllLoanAccounts method which returns a loanAccountsList" jsp page
	 */
	public String getAllLoanAccounts(Model model) {
		System.out.println("inside getAllLoanAccounts");
		List<LoanAccount> loanAccountsList = service.getAllLoanAccounts();
		model.addAttribute("loanAccounts", loanAccountsList);
		return "loanAccountsList";
	}
	/**
	 * getLoanAccount is  a method to display particular account details .
	 */	
	@RequestMapping("/viewLoanAccount")
	public String getLoanAccount(@RequestParam("accNo") String accNo,Model model ) {
	
		LoanAccount loanAccount=service.getLoanAccountByAccountNo(Integer.parseInt(accNo));
	model.addAttribute("key",loanAccount);
	return "viewLoanAccount";
	
}
	/**
	 * deleteLoanAccount is to delete a particular account
	 */
	@RequestMapping("/deleteLoanAccount")
	public String deleteLoanAccount(@RequestParam("accNo")String accNo,Model model) {
		
		
		service.deleteLoanAccount(Integer.parseInt(accNo));
		
				
		return "redirect:/loanAccounts";
		
		
	}
}
