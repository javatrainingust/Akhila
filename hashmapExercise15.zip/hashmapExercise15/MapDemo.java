package com.ust.collection.hashmap;

import java.util.HashMap;
import java.util.Map;

import com.ust.collection.array.Cat;

public class MapDemo {

	public static void main(String[] args) {
		Map<String, String> actor = new HashMap<String, String>();

		actor.put("Mohanlal", "Drishyam");

		actor.put("Dileep", "Thilakam");

		actor.put("Mammooty", "Truth");
		System.out.println("mohanlal movie=" + actor.get("Mohanlal"));
		System.out.println("Dileep  movie=" + actor.get("Dileep"));
		System.out.println("Mammooty movie=" + actor.get("Mammooty"));
		System.out.println();

		Cat cat1 = new Cat("rosy", 2);
		Cat cat2 = new Cat("pinky", 3);
		Cat cat3 = new Cat("rosy", 4);
		Map<Cat, String> cats = new HashMap<Cat, String>();
		cats.put(cat1, "Anju");
		cats.put(cat2, "Akhila");
		cats.put(cat3, "Arun");
		System.out.println("owner of dora is " + cats.get(cat1));
		System.out.println("owner of snow is " + cats.get(cat2));
		System.out.println("owner of kitty is " + cats.get(cat3));
	}

}
