/**
 * FDAccount  
 * 
 * FDAccount  extends to Account class it consist of interestCalculation method and autoRenewal method 
 *
 * 30/9/2020
 * 
*/



package com.trainingpractice.account.model;
/**
 * FDAccount class extends Account class and it implements Renewable class. two methods, for calculating interest interestCalculation method and autoRenewal method for autorenewal of account
 */


import com.trainingpractice.interest.calculation.ICalculator;
import com.trainingpractice.interest.calculation.IntrestCalculation;


public class FDAccount extends Account implements Renewable,Comparable<FDAccount> {

	public int tenure = 10;
	private boolean isAutoRenewal;
	private double principal;
	private int rate;
	

	/* No argument constructor */

	public FDAccount() {
		System.out.println("Inside Fd Account no arg constructor");
	}

	/* parameterized constructor */
	public FDAccount(int accountNo, String accountHolderName,float balance) {
		super(accountNo,accountHolderName,balance);
		
		
		System.out.println("parameterized constructor of fd account");

	}

	

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public boolean isAutoRenewal() {
		return isAutoRenewal;
	}

	public void setAutoRenewal(boolean isAutoRenewal) {
		this.isAutoRenewal = isAutoRenewal;
	}

	public double getPrincipal() {
		return principal;
	}

	public void setPrincipal(double principal) {
		this.principal = principal;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	IntrestCalculation interest = new IntrestCalculation();
	

//	public void updateRenewal(String renewalStatus){
//		if(renewalStatus.equals("yes")){
//			this.autoRenewal=true;
//			System.out.println("renewal Status is "+autoRenewal);
//		}
//	}

//	public void caluculateInterest() {
//	
//	
//	 interestRate = (principal*rate*1)/100;
//	System.out.println("Simple interest for FD is"+interestRate);
//	}
	/* calculating interest takes 2 arguments */
	public void interestCalculation(float amount, ICalculator interest) {
		System.out.println("Inside FDAccount");
		float interestfd = interest.calculateInterest(amount);
		System.out.println("Interest for Fd is=" + interestfd);
	}

	/* Auto renewal method which takes one argument tenure */

	@Override
	public void autoRenewal(int tenure) {
		if (isAutoRenewal == true) {

			if (tenure == 12) {
				System.out.println("please auto renew the account"+isAutoRenewal);
			} else if (tenure < 12)
				System.out.println("auto renew before renewel date ends"+isAutoRenewal);
			else {
				System.out.println("auto renewed"+isAutoRenewal);

			}
		
		}
}

	@Override
	public int compareTo(FDAccount fd) {
		
		return this.accountHolderName.compareTo(fd.getAccountHolderName());
		

}
}