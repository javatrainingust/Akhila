/**
 * CurrentAccount
 * 
 * CurrentAccount extends to Account class it consist of AmountLimit method
 *
 * 30/9/2020
 * 
*/

package com.trainingpractice.account.model;

/**
 * class to perform account operation of CurrentAccount
*/
public class CurrentAccount extends Account implements Comparable<CurrentAccount> {
	public float overDraftLimit;
	

	public CurrentAccount() {

		System.out.println("Inside current account no arg constructor");
	}

	public CurrentAccount(int accountNo, String accountHolderName,float overDraftLimit) {
		super(accountNo,accountHolderName,overDraftLimit);
		this.overDraftLimit=overDraftLimit;
		
		
		System.out.println("inside parameterized constructor of current account");
	}

	

	public float getOverDraftLimit() {
		return overDraftLimit;
	}

	public void setOverDraftLimit(float overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}

	public void AmountLimit(float balance) {
		if (balance < overDraftLimit) {
			System.out.println("Eligible for overdraft");
		} else {
			System.out.println("Not eligible for overdrafting");
		}
   
	}

	@Override
	public int compareTo(CurrentAccount o) {
		// TODO Auto-generated method stub
		return this.accountHolderName.compareTo(o.getAccountHolderName());
	}

}                                 
	
