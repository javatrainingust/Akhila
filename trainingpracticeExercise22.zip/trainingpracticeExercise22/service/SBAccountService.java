/**
 * SBAccountService
 * SBAccountService is a service class
 * 10/6/2020
*/
package com.trainingpractice.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.account.model.SBAccount;
import com.trainingpractice.bankaccount.dataaccess.SBAccountDAO;
import com.trainingpractice.bankaccount.dataaccess.SBAccountDAOImpl;
/** 
 *class used for add,delete,get the SB Account details
*/
public class SBAccountService {

	SBAccountDAO sBAccountDAOImpl;

	public SBAccountService() {

		sBAccountDAOImpl = new SBAccountDAOImpl();

	}
	/**
	 *  getAllSBAccounts method is for getting all the SBAccount
	*/
	public List<SBAccount> getAllSBAccounts() {

		List<SBAccount> sBAccountList = sBAccountDAOImpl.getAllSBAccounts();
		Iterator<SBAccount> iterator = sBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account No is= " + sb.getAccountNo());
			System.out.println("Accont holder name is = " + sb.getAccountHolderName());
			//System.out.println("Account duration is=" + sb.getDuration());
			System.out.println("Account balance is= " + sb.getbalance());

		}

		return sBAccountList;

	}
	/**
	 *  getSBAccountByAccountNo method is for getting the particular  SBAccount
	*/

	public SBAccount getSBAccountByAccountNo(int accountNo) {

		SBAccount sb = sBAccountDAOImpl.getSBAccountByAccountNo(accountNo);

		System.out.println("Account No is= " + sb.getAccountNo());
		System.out.println("Accont holder name is = " + sb.getAccountHolderName());
		//System.out.println("Account duration is=" + sb.getDuration());
		System.out.println("Account balance is= " + sb.getbalance());

		return sb;

	}
	/**
	 *  deleteSBAccount method is for deleting a particular  SBAccount
	*/
	public void deleteSBAccount(int accountNo) {

		sBAccountDAOImpl.deleteSBAccount(accountNo);

	}
	/**
	 * method for sorting SBAccounts by account holder name
	 */
	public List<SBAccount> getAllSBAccountsSortedByAccountHolderName() {
		
		List<SBAccount> sBAccountList = sBAccountDAOImpl.getAllSBAccounts();
		//Collections.sort(sBAccountList);
		
		Stream<SBAccount> sBAccountStream= sBAccountList.stream();

		Stream<SBAccount> sortedStream = sBAccountStream.sorted();

		List sortedSBAccountList = sortedStream.collect(Collectors.toList());
		

		Iterator<SBAccount> iterator = sortedSBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account No is= " + sb.getAccountNo());
			System.out.println("Accont holder name is = " + sb.getAccountHolderName());
			//System.out.println("Account duration is=" + sb.getDuration());
			System.out.println("Account balance is= " + sb.getbalance());

		}

		return sBAccountList;
	}
	/**
	 * method for sorting SB account by balance
	 */
	public List<SBAccount> getAllSBAccountsSortedByBalance() {
		List<SBAccount> sBAccountList = sBAccountDAOImpl.getAllSBAccounts();
		//Collections.sort(sBAccountList,new SBAccountComparator());
		Stream<SBAccount> sBAccountStream= sBAccountList.stream();

		Stream<SBAccount> sortedStream = sBAccountStream.sorted(new SBAccountComparator());

		List sortedSBAccountList = sortedStream.collect(Collectors.toList());
		

		Iterator<SBAccount> iterator = sortedSBAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Account No is= " + sb.getAccountNo());
			System.out.println("Accont holder name is = " + sb.getAccountHolderName());
			//System.out.println("Account duration is=" + sb.getDuration());
			System.out.println("Account balance is= " + sb.getbalance());

		}

		return sBAccountList;
		
	}
		
	/**
	 * method for adding  current account
    */
public void addSBAccount(SBAccount sBAccount) {
		
		boolean isAdded = sBAccountDAOImpl.addSBAccount(sBAccount);
		
		if(!isAdded){
			
			System.out.println("The Account holder already exist");
		}
		else{
			System.out.println("The Account holder is  successfully added");
			
		}
		
	}
/**
 * method for updating SBAccount
*/
	public void updateSBAccount(SBAccount sBAccount) {
		
		sBAccountDAOImpl.updateSBAccount(sBAccount);
	}
		
		
	

}



