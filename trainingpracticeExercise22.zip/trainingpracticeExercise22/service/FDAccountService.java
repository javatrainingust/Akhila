/**
 * FDAccountService
 * FDAccountService is a service class
 * 10/6/2020
*/

package com.trainingpractice.service;

import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.bankaccount.dataaccess.FDAccountDAO;
import com.trainingpractice.bankaccount.dataaccess.FDAccountDAOImpl;

/**
 * class used for add,delete,get the FD Account details
 */
public class FDAccountService {
	FDAccountDAO fDAccountDAOImpl;

	public FDAccountService() {

		fDAccountDAOImpl = new FDAccountDAOImpl();

	}

	/**
	 * getAllFDAccounts method is for getting all the FDAccount
	 */
	public List<FDAccount> getAllFDAccounts() {

		List<FDAccount> fDAccountList = fDAccountDAOImpl.getAllFDAccounts();
		Iterator<FDAccount> iterator = fDAccountList.iterator();

		while (iterator.hasNext()) {

			FDAccount fd = iterator.next();

			System.out.println("Account No is= " + fd.getAccountNo());
			System.out.println("Accont holder name is = " + fd.getAccountHolderName());
			System.out.println("Account balance is=" + fd.getBalance());
		}

		return fDAccountList;

	}

	/**
	 * getFDAccountByAccountNo method is for getting the particular FDAccount
	 */
	public FDAccount getFDAccountByAccountNo(int accountNo) {

		FDAccount fd = fDAccountDAOImpl.getFDAccountByAccountNo(accountNo);

		System.out.println("Account No is= " + fd.getAccountNo());
		System.out.println("Accont holder name is = " + fd.getAccountHolderName());
		System.out.println("Account tenure is= " + fd.getTenure());
		return fd;

	}

	/**
	 * deleteFDAccount method is for deleting a particular FDAccount
	 */
	public void deleteFDAccount(int accountNo) {

		fDAccountDAOImpl.deleteFDAccount(accountNo);

	}

	/**
	 * method for sorting FDAccounts by account holder name
	 */
	public List<FDAccount> getAllFDAccountsSortedByAccountHolderName() {

		List<FDAccount> fDAccountList = fDAccountDAOImpl.getAllFDAccounts();
		// Collections.sort(fDAccountList);
		Stream<FDAccount> fDAccountStream = fDAccountList.stream();

		Stream<FDAccount> sortedStream = fDAccountStream.sorted();

		List sortedFDAccountList = sortedStream.collect(Collectors.toList());
		Iterator<FDAccount> iterator = sortedFDAccountList.iterator();

		while (iterator.hasNext()) {

			FDAccount fd = iterator.next();

			System.out.println("Account No is= " + fd.getAccountNo());
			System.out.println("Accont holder name is = " + fd.getAccountHolderName());
			System.out.println("Account balance is=" + fd.getBalance());

		}

		return fDAccountList;
	}

	/**
	 * method for sorting current account by balance
	 */
	public List<FDAccount> getAllFDAccountsSortedByBalance() {

		List<FDAccount> fDAccountList = fDAccountDAOImpl.getAllFDAccounts();
		// Collections.sort(fDAccountList,new FDAccountComparator());
		Stream<FDAccount> fDAccountStream = fDAccountList.stream();

		Stream<FDAccount> sortedStream = fDAccountStream.sorted(new FDAccountComparator());

		List sortedFDAccountList = sortedStream.collect(Collectors.toList());
		Iterator<FDAccount> iterator = sortedFDAccountList.iterator();

		while (iterator.hasNext()) {

			FDAccount fd = iterator.next();

			System.out.println("Account No is= " + fd.getAccountNo());
			System.out.println("Accont holder name is = " + fd.getAccountHolderName());
			System.out.println("Account balance is=" + fd.getBalance());
		}

		return fDAccountList;
	}

	/**
	 * method for adding FDAccount
	 */
	public void addFDAccount(FDAccount fDAccount) {

		boolean isAdded = fDAccountDAOImpl.addFDAccount(fDAccount);

		if (!isAdded) {

			System.out.println("The Account holder already exist");
		} else {
			System.out.println("The Account holder is  successfully added");

		}

	}

	/**
	 * method for updating FDAccount
	 */
	public void updateFDAccount(FDAccount fDAccount) {

		fDAccountDAOImpl.updateFDAccount(fDAccount);
	}

}
