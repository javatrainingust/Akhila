/**
 * CurrentAccountServiceTest 
 * CurrentAccountServiceTest  is for performing jUnit test operations
 * 10/6/2020
*/

package com.trainingpractice.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.trainingpractice.account.model.CurrentAccount;
import com.trainingpractice.account.model.FDAccount;
import com.trainingpractice.bankaccount.dataaccess.CurrentAccountDAOImpl;

/**
 * This class Contains test cases
 */
class CurrentAccountServiceTest {

	CurrentAccountService currentAccountService;
	/**
	 * Constructor for LoanAccountServiceTest
	 */
	
	public CurrentAccountServiceTest() {
		currentAccountService = new CurrentAccountService();
		currentAccountService.addCurrentAccount(new CurrentAccount(1000, "Akhila", 1000));
		currentAccountService.addCurrentAccount(new CurrentAccount(1001, "Anjali", 10000));
	}
	/**
	 * Test Method to add account successfully
	 */
	@Test
	void testAddCurrentAccountSuccess() {
		int expectedValue = 7;
		currentAccountService.addCurrentAccount(new CurrentAccount(1005, "Nayana",3000));
		
		List actualValue = currentAccountService.getAllCurrentAccounts();
		assertEquals(expectedValue, actualValue.size());

	}
	/**
	 * Test Method if there is failure to add account
	 */
	@Test
	public void testAddCurrentAccountFailure() {
		
			String expected ="Akhila";
			currentAccountService.addCurrentAccount(new CurrentAccount(1000, "Anjali",10000));
		
			String actual = currentAccountService.getCurrentAccountByAccountNo(1000).getAccountHolderName();
			assertEquals(expected, actual); 
			
		}
	/**
	 * Test method to update account
	 */
	@Test
	public void testUpdateCurrentAccount() {
		  
		currentAccountService.updateCurrentAccount(new CurrentAccount(1001, "Anjali", 25000));
		float actual = currentAccountService.getCurrentAccountByAccountNo(1001).getOverDraftLimit();
		float expected = 25000;
		assertEquals(expected, actual);
		
		
	}
	@Test
	void testGetAllCurrentAccountsSortedByAccountHolderName() {
		String expected = "Anjali";
		
		CurrentAccount actual = currentAccountService.getAllCurrentAccountsSortedByAccountHolderName().get(1);
		assertEquals(expected, actual.getAccountHolderName());
	}

	/**
	 * This test case is for testing whether expected and actual values are same
	 */
	@Test
	void testGetAllCurrentAccountsSortedByOverDraftLimit() {
		String expected = "Akhila";
		//CurrentAccountService currentService = new CurrentAccountService();
		CurrentAccount actual = currentAccountService.getAllCurrentAccountsSortedByOverDraftLimit().get(0);
		assertEquals(expected, actual.getAccountHolderName());
	}
	


	/*
	 * expectedList=new ArrayList<CurrentAccount>();
	 * 
	 * CurrentAccount ca1 = new CurrentAccount(1000, "Akhila", 1000); CurrentAccount
	 * ca2 = new CurrentAccount(1001, "Anjali", 1500); CurrentAccount ca3 = new
	 * CurrentAccount(1002, "Arun", 2000); CurrentAccount ca4 = new
	 * CurrentAccount(1003, "Anu",
	 * 3000);expectedList.add(ca1);expectedList.add(ca2);expectedList.add(ca3);
	 * expectedList.add(ca4);
	 * 
	 * }
	 * 
	 *//**
		 * This test case is for testing whether expected and actual values are same
		 */
	/*
	 * @Test void testGetAllCurrentAccounts() { CurrentAccountDAOImpl
	 * currentAccountDAOImpl = new CurrentAccountDAOImpl(); List<CurrentAccount>
	 * actual = currentAccountDAOImpl.getAllCurrentAccounts(); List<CurrentAccount>
	 * expected = expectedList; assertEquals(expected.size(), actual.size());
	 * 
	 * }
	 * 
	 *//**
		 * This test case is for testing whether expected and actual values are same
		 */
	/*
	 * @Test void testGetCurrentAccountByAccountNo() { String expected = "Anu";
	 * CurrentAccountDAOImpl currentAccountDAOImpl = new CurrentAccountDAOImpl();
	 * CurrentAccount actual =
	 * currentAccountDAOImpl.getCurrentAccountByAccountNo(1003);
	 * assertEquals(expected, actual.getAccountHolderName());
	 * 
	 * }
	 * 
	 *//**
		 * This test case is for testing whether expected and actual values are same
		 */

	/*
	 * @Test void testDeleteCurrentAccount() { CurrentAccountDAOImpl
	 * currentAccountDAOImpl = new CurrentAccountDAOImpl();
	 * 
	 * currentAccountDAOImpl.deleteCurrentAccount(1002);
	 * 
	 * List<CurrentAccount> actual = currentAccountDAOImpl.getAllCurrentAccounts();
	 * 
	 * assertEquals(expectedList.size() - 1, actual.size()); }
	 * 
	 *//**
		 * This test case is for testing whether expected and actual values are same
		 */

	
	

}
