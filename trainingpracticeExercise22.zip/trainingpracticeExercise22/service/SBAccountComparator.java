/**
 * SBAccountComparator
 * 
 *SBAccountComparator class is implemented from Comparator
 *
 * Date:07/10/2020
 * 
*/

package com.trainingpractice.service;

import java.util.Comparator;

import com.trainingpractice.account.model.SBAccount;

/**
 * Class used for sorting balance in SB accounts .
 */
public class SBAccountComparator implements Comparator<SBAccount> {
	/**
	 * method for sorting balance
	 */
	@Override
	public int compare(SBAccount o1, SBAccount o2) {

		return (int) (o1.getbalance() - o2.getbalance());
	}

}
