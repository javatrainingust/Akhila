/**
 * LoanAccountComparator
 * 
 * LoanAccountComparator class is implemented from Comparator
 *
 * Date:07/10/2020
 * 
*/


package com.trainingpractice.service;

import java.util.Comparator;

import com.trainingpractice.account.model.LoanAccount;
/**
*This is a class used for sorting loanOutStanding in Loan Accounts.
*/
public class LoanAccountComparator  implements Comparator<LoanAccount>{
	/**
	 * method for sorting  LoanOutStanding
	 */
	@Override
	public int compare(LoanAccount o1, LoanAccount o2) {
		
		return (int)(o1.getLoanOutStanding()-o2.getLoanOutStanding());
	}
	

}
